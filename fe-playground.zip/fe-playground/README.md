# FePlayground

<a alt="Nx logo" href="https://nx.dev" target="_blank" rel="noreferrer"><img src="https://raw.githubusercontent.com/nrwl/nx/master/images/nx-logo.png" width="45"></a>

✨ Your new, shiny [Nx workspace](https://nx.dev) is ready ✨.

[Learn more about this workspace setup and its capabilities](https://nx.dev/getting-started/tutorials/react-monorepo-tutorial?utm_source=nx_project&utm_medium=readme&utm_campaign=nx_projects) or run `npx nx graph` to visually explore what was created. Now, let's get you up to speed!

## CLI

### Create Workspaces-based Monorepo

```sh
npx create-nx-workspace tsmono --preset=ts [--pm]
```

This generates a NPM workspaces setup:

- `nx.json`: caching + task pipelines.
- `nx` and `@nx/js` dependency in the root-level `package.json`

Specify `--pm` option to switch to PNPM/Yarn/Bun.

### Manage Projects (React Application/Library, JS Library, ...)

Use Nx plugins and their code generators to scaffold projects or integrate features into existing ones.

Underneath, the plugins automatically:

- Configure `package.json` file and the `exports:` property.
- Set up `tsconfig*` files.

To list the current list of projects:

```sh
npx nx show projects
```

To generate a new application, use:

```sh
npx nx g @nx/react:app apps/first-example --name=@fe-playground/first-example
```

To generate a new library, use:

```sh
# pure JS lib: https://nx.dev/docs/technologies/typescript/generators#library
npx nx g @nx/js:lib libs/counter/data-access --name=@fe-playground/counter-data-access --tags=scope:counter,type=data-access
npx nx g @nx/js:lib libs/counter/utils --name=@fe-playground/counter-utils --tags=scope:counter,type=util

# react lib
npx nx g @nx/react:lib libs/counter/features --name=@fe-playground/counter-features --tags=scope:counter,type:feature
npx nx g @nx/react:lib libs/counter/ui --name=@fe-playground/counter-ui --tags=scope:counter,type:ui
```

To delete existing application/library, use:

```sh
# https://nx.dev/docs/reference/workspace/generators#remove
npx nx g @nx/workspace:remove @fe-playground/shared
```

To relocate existing application/library, use:

```sh
# https://nx.dev/docs/reference/workspace/generators#move
npx nx g @nx/workspace:move --projectName=@fe-playground/shared --newProjectName=@fe-playground/shared-ui libs/shared/ui
```

Clean `package-lock.json`:

```sh
npm prune
```

You can use `npx nx list` to get a list of installed plugins. Then, run `npx nx list <plugin-name>` to learn about more specific capabilities of a particular plugin. Alternatively, [install Nx Console](https://nx.dev/getting-started/editor-setup?utm_source=nx_project&utm_medium=readme&utm_campaign=nx_projects) to browse plugins and generators in your IDE.

[Learn more about Nx plugins &raquo;](https://nx.dev/concepts/nx-plugins?utm_source=nx_project&utm_medium=readme&utm_campaign=nx_projects) | [Browse the plugin registry &raquo;](https://nx.dev/plugin-registry?utm_source=nx_project&utm_medium=readme&utm_campaign=nx_projects)

### Manage React Components

```sh
npx nx g @nx/react:component libs/counter/ui/src/my-component.tsx
```

### Run tasks

To run the dev server for your app, use:

```sh
npx nx serve counter
```

To create a production bundle:

```sh
npx nx build counter
```

To run TypeScript check, use:

```sh
npx nx typecheck fe-playground
```

To see all available targets to run for a project, run:

```sh
npx nx show project fe-playground
```

These targets are either [inferred automatically](https://nx.dev/concepts/inferred-tasks?utm_source=nx_project&utm_medium=readme&utm_campaign=nx_projects) or defined in the `project.json` or `package.json` files.

[More about running tasks in the docs &raquo;](https://nx.dev/features/run-tasks?utm_source=nx_project&utm_medium=readme&utm_campaign=nx_projects)

### Integrate NX into an existing project

```sh
npx nx init
```

### Reset NX

```sh
# 1. clear task cache
# 2. clear workspace metadata
# 3. stop NX daemon (background process that watch files and store graph data)
npx nx reset
npx nx reset --only-cache
npx nx reset --only-daemon
npx nx reset --only-workspace-data
```

### Synchronize NX

```sh
# update TypeScript Project References in root tsconfig.json
npx nx sync
```

### Plugins

```sh
npx nx add @nx/eslint
npx nx add @nx/eslint-plugin
npx nx add @nx/devkit

# view inferred tasks
npx nx show project my-app-or-my-lib --web

# lint
npx nx lint my-app-or-my-lib
```

### Custom Plugins / Local Generators

```sh
npx nx add @nx/plugin

# create a "plugin"
npx nx g @nx/plugin:plugin tools/my-plugin

# create a "generator" inside plugin
npx nx g @nx/plugin:generator tools/my-plugin src/generators/my-generator

# run a "generator"
# NOTE: '@fe-playground/my-plugin' must be taken from tools/my-plugin/package.json
npx nx g @fe-playground/my-plugin:my-generator mylib
```

Some generator schema properties:

```json
{
  // ...
  "properties": {
    "name": {
      "type": "string",
      "$default": {
        // use the positional CLI argument at the given index
        "$source": "argv",
        "index": 0
      }
    }
  }
}
```

```json
{
  // ...
  "properties": {
    "name": {
      "type": "string",
      "$default": {
        // use the current project name as value
        "$source": "projectName"
      }
    }
  }
}
```

```json
{
  // ...
  "properties": {
    "name": {
      "type": "string",
      "$default": {
        // ie. if you run `nx g @fe-playground/my-plugin:my-generator mylib` at the directory that holds nx.json, it resolves to ""
        // ie. if you run the command at the "/home/abc/sourcecode/fe-playground/apps/my-app/src", it resolves to "./apps/my-app/src"
        "$source": "workingDirectory"
      }
    }
  }
}
```

When the option is not provided on the command line, `x-prompt` define an interactive prompt for the user to either type or choose from a list:

```json
{
  // ...
  "properties": {
    "style": {
      "type": "string",
      "description": "The file extension to be used for style files.",
      // "x-prompt": "What name would you like to use?" // Short form, display text only
      // Long form
      "x-prompt": {
        "message": "Which stylesheet format would you like to use?", // description
        "type": "list", // prompt type: "input", "list", "confirmation"
        "items": [
          // choices for "list" prompt type
          { "value": "css", "label": "CSS" },
          { "value": "scss", "label": "SASS (.scss)" },
          { "value": "less", "label": "LESS" }
        ]
        // "multiselect": true // if allows more than 1 value
      }
    }
  }
}
```

### Set up CI!

1. To connect to Nx Cloud, run the following command:

```sh
npx nx connect
```

Connecting to Nx Cloud ensures a [fast and scalable CI](https://nx.dev/ci/intro/why-nx-cloud?utm_source=nx_project&utm_medium=readme&utm_campaign=nx_projects) pipeline. It includes features such as:

- [Remote caching](https://nx.dev/ci/features/remote-cache?utm_source=nx_project&utm_medium=readme&utm_campaign=nx_projects)
- [Task distribution across multiple machines](https://nx.dev/ci/features/distribute-task-execution?utm_source=nx_project&utm_medium=readme&utm_campaign=nx_projects)
- [Automated e2e test splitting](https://nx.dev/ci/features/split-e2e-tasks?utm_source=nx_project&utm_medium=readme&utm_campaign=nx_projects)
- [Task flakiness detection and rerunning](https://nx.dev/ci/features/flaky-tasks?utm_source=nx_project&utm_medium=readme&utm_campaign=nx_projects)

2. Use the following command to configure a CI workflow for your workspace:

```sh
npx nx g ci-workflow
```

[Learn more about Nx on CI](https://nx.dev/ci/intro/ci-with-nx#ready-get-started-with-your-provider?utm_source=nx_project&utm_medium=readme&utm_campaign=nx_projects)

## Knowledge

### Project Crystal

- Major architectural feature introduced in NX 18.
- No need for massive `project.json`.
- Automatically read and infer _targets_ (e.g., lint, test, build) by looking directly at 3rd-party framework/library configuration file (e.g., `vite.config.mts`, `package.json`, ...) to apply task execution and caching.
- Introduce `nx add` command auto install plugins.

### TypeScript Project References

- Code editor supports autocomplete and navigation. E.g., root-level `tsconfig.json` references both `myviteapp` application and `mytslib` library/package which allows editor to correctly find all the available projects.
- Improve compilation speed and memory usage.
- `npx nx sync` dynamically update the `"references":` property in each project's `tsconfig.json` by scanning your codebase via `import` (or `require`) statement.

### `tsconfig.json`

NX builds on top of the package manager's workspace feature using `references:` field inside root `tsconfig.json`. It now requires going into individual applications/libraries `tsconfig.json` to figure out what to do next.

```json
{
  // ...,
  "files": [],
  "references": [
    {
      "path": "./apps/fe-playground"
    },
    {
      "path": "./apps/first-example"
    },
    {
      "path": "./libs/shared/ui"
    },
    {
      "path": "./libs/counter/api"
    },
    {
      "path": "./libs/counter/features"
    },
    {
      "path": "./libs/counter/ui"
    },
    {
      "path": "./libs/counter/utils"
    }
  ]
}
```

### `package.json`

You can configure NX React generators to enforce inlining NX configuration in the app/lib `package.json` file instead of `project.json` (Project Crystal).

```json
// app/first-example/package.json
{
  //
  "nx": {
    "name": "@fe-playground/first-example"
    // ...
  }
}
```

The above example shows that NX can customize the name of the project it managed, also states that NX manage projects via `project.json` or `package.json`, not directory name.

Next, `@nx/dependency-checks` rule scans the monorepo source code, sees that root `package.json` contains `react`, `@reduxjs/toolkit`, ... yet`apps/first-example/package.json` not => Throw an error.

```js
// apps/first-example/eslint.config.mjs
export default [
  // ...
  {
    files: ["**/*.json"],
    rules: {
      // NOTE: do not suppress publishable libs/apps
      "@nx/dependency-checks": "off",
    },
  },
];
```

## Install Nx Console

Nx Console is an editor extension that enriches your developer experience. It lets you run tasks, generate code, and improves code autocompletion in your IDE. It is available for VSCode and IntelliJ.

[Install Nx Console &raquo;](https://nx.dev/getting-started/editor-setup?utm_source=nx_project&utm_medium=readme&utm_campaign=nx_projects)

## Useful links

Learn more:

- [Learn more about this workspace setup](https://nx.dev/getting-started/tutorials/react-monorepo-tutorial?utm_source=nx_project&utm_medium=readme&utm_campaign=nx_projects)
- [Learn about Nx on CI](https://nx.dev/ci/intro/ci-with-nx?utm_source=nx_project&utm_medium=readme&utm_campaign=nx_projects)
- [Releasing Packages with Nx release](https://nx.dev/features/manage-releases?utm_source=nx_project&utm_medium=readme&utm_campaign=nx_projects)
- [What are Nx plugins?](https://nx.dev/concepts/nx-plugins?utm_source=nx_project&utm_medium=readme&utm_campaign=nx_projects)

And join the Nx community:

- [Discord](https://go.nx.dev/community)
- [Follow us on X](https://twitter.com/nxdevtools) or [LinkedIn](https://www.linkedin.com/company/nrwl)
- [Our Youtube channel](https://www.youtube.com/@nxdevtools)
- [Our blog](https://nx.dev/blog?utm_source=nx_project&utm_medium=readme&utm_campaign=nx_projects)

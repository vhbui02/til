import js from "@eslint/js";
import nx from "@nx/eslint-plugin";
import vitestPlugin from "@vitest/eslint-plugin";
import prettierConfig from "eslint-config-prettier/flat";
import checkFilePlugin from "eslint-plugin-check-file";
import importPlugin from "eslint-plugin-import";
import jsxA11yPlugin from "eslint-plugin-jsx-a11y";
import reactPlugin from "eslint-plugin-react";
import reactHooksPlugin from "eslint-plugin-react-hooks";
import reactRefreshPlugin from "eslint-plugin-react-refresh";
import { defineConfig } from "eslint/config";
import globals from "globals";
import * as jsoncParser from "jsonc-eslint-parser";
import tseslint from "typescript-eslint";

export default defineConfig([
  // Global ignores (Combined Single Repo + Nx patterns)
  {
    name: "global-ignores",
    ignores: [
      "**/node_modules/**",
      "**/dist/**",
      "**/build/**",
      "**/out-tsc/**",
      "**/coverage/**",
      "**/.yarn/**",
      "**/temp/**",
      "**/.temp/**",
      "**/tmp/**",
      "**/.tmp/**",
      "public/mockServiceWorker.js",
      "generators/**",
      "**/vite.config.*.timestamp*",
      "**/vitest.config.*.timestamp*",
    ],
  },

  // ESLint & TypeScript Recommended
  js.configs.recommended,
  ...tseslint.configs.strict,
  ...tseslint.configs.stylistic,

  // Nx Base Configs
  ...nx.configs["flat/base"],
  ...nx.configs["flat/typescript"],
  ...nx.configs["flat/javascript"],

  // Import Plugin
  // Problem: Inside an NX monorepo, ESLint sees the plugin registered more than once (1 at base, N at individual projects)
  // Fix: bypass plugin registration, only apply the rule
  {
    name: "import-consolidated-configuration",
    plugins: {
      import: importPlugin,
    },
    rules: {
      ...importPlugin.flatConfigs.recommended.rules,
      ...importPlugin.flatConfigs.typescript.rules,
    },
  },

  // Accessibility Plugin
  {
    name: "jsx-a11y-configuration",
    plugins: {
      "jsx-a11y": jsxA11yPlugin,
    },
    rules: {
      ...jsxA11yPlugin.flatConfigs.recommended.rules,
    },
  },

  // Language Options and Shared Settings
  {
    name: "language-options",
    files: ["**/*.{js,jsx,ts,tsx,cjs,mjs,cts,mts}"],
    languageOptions: {
      ecmaVersion: "latest",
      sourceType: "module",
      globals: {
        ...globals.browser,
        ...globals.node,
        ...globals.serviceworker,
      },
      parserOptions: {
        projectService: {
          allowDefaultProject: ["eslint.config.mjs"],
        },
        tsconfigRootDir: import.meta.dirname,
      },
    },
    settings: {
      react: {
        version: "detect", // Auto-detect React version for React 17+
      },
      "import/resolver": {
        typescript: {
          alwaysTryTypes: true,
          project: ["./tsconfig.base.json"], // Monorepo path aliases
        },
      },
      vitest: { typecheck: true },
    },
  },

  // React Refresh (HMR)
  {
    name: "react-refresh-configuration",
    plugins: {
      "react-refresh": reactRefreshPlugin,
    },
    rules: {
      "react-refresh/only-export-components": [
        "warn",
        { allowConstantExport: true },
      ],
    },
  },

  // React & React Hooks
  {
    name: "react-configuration",
    // in flat config, spreading the rules tells ESLint to enforce rules prefixed with 'react-hooks/`
    ...reactPlugin.configs.flat.recommended, // NOTE: this is NOT the rule, this is the object
    ...reactPlugin.configs.flat["jsx-runtime"], // NOTE: this too, is NOT the rule
    plugins: {
      react: reactPlugin,
      "react-hooks": reactHooksPlugin,
    },
    rules: {
      ...reactHooksPlugin.configs.recommended.rules, // NOTE: this IS the rule
      "react/prop-types": "off",
      "react/display-name": "off",
      "react/react-in-jsx-scope": "off",
      "react/jsx-pascal-case": [
        "warn",
        {
          allowAllCaps: false,
          ignore: [],
        },
      ],
    },
  },

  // Vitest configuration
  {
    name: "vitest-configuration",
    files: [
      "**/__tests__/**/*.{ts,tsx}",
      "**/*.spec.{ts,tsx}",
      "**/*.test.{ts,tsx}",
    ],
    plugins: {
      vitest: vitestPlugin,
    },
    rules: {
      ...vitestPlugin.configs.recommended.rules,
    },
  },

  // Unified Custom Rules & Nx Boundaries
  {
    name: "custom-rules",
    files: ["**/*.{js,jsx,ts,tsx,cjs,mjs,cts,mts}"],
    rules: {
      // Nx Module Boundaries (Replacing custom import/no-restricted-paths)
      "@nx/enforce-module-boundaries": [
        "error",
        {
          enforceBuildableLibDependency: true,
          allow: ["^.*/eslint(\\.base)?\\.config\\.[cm]?[jt]s$"],
          depConstraints: [
            {
              sourceTag: "*",
              onlyDependOnLibsWithTags: ["*"],
            },
          ],
        },
      ],

      // TypeScript overrides
      "no-unused-vars": "off",
      "@typescript-eslint/no-unused-vars": [
        "warn",
        {
          varsIgnorePattern: "^_",
          argsIgnorePattern: "^_",
        },
      ],
      "@typescript-eslint/no-explicit-any": "off",
      "@typescript-eslint/no-empty-function": "off",
      "@typescript-eslint/explicit-function-return-type": "off",
      "@typescript-eslint/explicit-module-boundary-types": "off",
      "@typescript-eslint/consistent-type-definitions": [2, "type"],
      "@typescript-eslint/consistent-type-imports": [
        2,
        {
          prefer: "type-imports",
          fixStyle: "separate-type-imports",
          disallowTypeAnnotations: true,
        },
      ],

      // JSX A11y
      "jsx-a11y/anchor-is-valid": "off",

      // Enforce pre-typed Redux hooks
      "no-restricted-imports": [
        2,
        {
          paths: [
            {
              name: "react-redux",
              importNames: ["useSelector", "useStore", "useDispatch"],
              message: "Please use pre-typed versions instead.",
            },
          ],
        },
      ],

      // Import plugin rules
      "import/no-cycle": "error",
      "import/default": "off",
      "import/named": "off",
      "import/namespace": "off",
      "import/no-unresolved": "off",
      "import/no-named-as-default-member": "off",
      "import/no-named-as-default": "off",

      // NOTE: let formatter dictates
      // "import/order": [
      //     "error",
      //     {
      //         groups: [
      //             "builtin",
      //             "external",
      //             "internal",
      //             "parent",
      //             "sibling",
      //             "index",
      //             "object",
      //             "type",
      //         ],
      //         "newlines-between": "always",
      //         alphabetize: { order: "asc", caseInsensitive: true },
      //     },
      // ],

      // Cross-platform consistency
      "linebreak-style": ["error", "unix"],
    },
  },

  // File and Folder Naming Conventions
  {
    name: "files-naming-convention",
    // Expanded glob for Nx monorepos to catch libs/ and apps/
    files: ["**/*/src/**/*.{js,jsx,ts,tsx,cjs,mjs,cts,mts}"],
    plugins: {
      "check-file": checkFilePlugin,
    },
    rules: {
      "check-file/filename-naming-convention": [
        "error",
        { "**/*.{ts,tsx}": "KEBAB_CASE" },
        { ignoreMiddleExtensions: true },
      ],
    },
  },
  {
    name: "folder-naming-convention",
    files: ["**/*/src/**/!(__tests__)/*"],
    plugins: {
      "check-file": checkFilePlugin,
    },
    rules: {
      "check-file/folder-naming-convention": [
        "error",
        { "**/*": "KEBAB_CASE" },
      ],
    },
  },

  // NX Enforce Module Boundaries
  {
    files: ["**/*.{js,jsx,ts,tsx,cjs,mjs,cts,mts}"],
    rules: {
      "@nx/enforce-module-boundaries": [
        "error",
        {
          allow: [],
          depConstraints: [
            {
              sourceTag: "scope:counter",
              onlyDependOnLibsWithTags: ["scope:counter"],
            },
            {
              sourceTag: "scope:social-media",
              onlyDependOnLibsWithTags: ["scope:social-media"],
            },
            // {
            //   sourceTag: "type:view",
            //   onlyDependOnLibsWithTags: ["type:view", "type:logic"],
            // },
            // {
            //   sourceTag: "type:logic",
            //   onlyDependOnLibsWithTags: ["type:logic"],
            // },
          ],
        },
      ],
    },
    "import/no-restricted-paths": [
      "error",
      {
        zones: [
          {
            target: "",
          },
        ],
      },
    ],
  },

  // Prettier (Must be last to disable conflicting rules)
  prettierConfig,
]);

# scaffold-plugin

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build scaffold-plugin` to build the library.

## Running unit tests

Run `nx test scaffold-plugin` to execute the unit tests via [Vitest](https://vitest.dev/).

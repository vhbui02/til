import {
  addProjectConfiguration,
  formatFiles,
  generateFiles,
  type Tree,
} from "@nx/devkit";
import * as path from "path";
import type { ScaffoldGeneratorGeneratorSchema } from "./schema";

export async function scaffoldGeneratorGenerator(
  tree: Tree,
  options: ScaffoldGeneratorGeneratorSchema
) {
  const projectRoot = `libs/${options.name}`;
  addProjectConfiguration(tree, options.name, {
    root: projectRoot,
    projectType: "library",
    sourceRoot: `${projectRoot}/src`,
    targets: {},
  });
  // dynamically copy and render templates
  generateFiles(tree, path.join(__dirname, "files"), projectRoot, options);
  await formatFiles(tree);
}

export default scaffoldGeneratorGenerator;

export interface ScaffoldGeneratorGeneratorSchema {
  name: string;
}

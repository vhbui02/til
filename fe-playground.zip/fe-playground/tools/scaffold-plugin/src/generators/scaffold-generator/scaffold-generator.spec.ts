import { Tree, readProjectConfiguration } from "@nx/devkit";
import { createTreeWithEmptyWorkspace } from "@nx/devkit/testing";

import { scaffoldGeneratorGenerator } from "./scaffold-generator";
import { ScaffoldGeneratorGeneratorSchema } from "./schema";

describe("scaffold-generator generator", () => {
  let tree: Tree;
  const options: ScaffoldGeneratorGeneratorSchema = { name: "test" };

  beforeEach(() => {
    tree = createTreeWithEmptyWorkspace();
  });

  it("should run successfully", async () => {
    await scaffoldGeneratorGenerator(tree, options);
    const config = readProjectConfiguration(tree, "test");
    expect(config).toBeDefined();
  });
});

import { App } from "@/app";
import { enableMocking } from "@/testing/mocks";
import { StrictMode } from 'react';
import { createRoot } from "react-dom/client";

const container = document.getElementById('root');
if (container === null) {
  throw new Error("Root element with ID 'root' was not found in the document. Ensure there is a corresponding HTML element with the ID 'root' in your HTML file.");
}

// always await worker.start() promise
// Service Worker registration is asynchronous. If it failed to await, it may result in a race condition between the worker registration and the initial requests the app made
enableMocking().then(() => {
  const root = createRoot(container);
  root.render(
    <StrictMode>
      <App />
    </StrictMode>
  )
})
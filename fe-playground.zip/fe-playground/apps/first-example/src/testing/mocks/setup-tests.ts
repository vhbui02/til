import { server } from "@/testing/mocks/server";
import { afterEach, beforeEach } from "node:test";

beforeAll(() => server.listen({
  onUnhandledRequest: "error"
}));
afterAll(() => server.close());

beforeEach(() => { /* ... */ });
afterEach(() => server.resetHandlers());
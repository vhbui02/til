import { setupServer } from 'msw/node';
import { handlers } from "./handlers";

// node.js processes, server-side environments, ...
// interception layer: class/module patching via @mswjs/interceptors to hook into http, https, fetch, XMLHttpRequest
// network visibility: Node network calls are caught seamlessly inside OS process lifecycle, no browser UI
// scope restrictions: global across the execution scope of the entire active Node.js thread
export const server = setupServer(...handlers);
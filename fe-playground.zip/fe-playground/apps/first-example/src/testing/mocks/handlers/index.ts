import { httpHandlers } from "@/testing/mocks/handlers/http";

export const handlers = [
  ...httpHandlers,
];
# @fe-playground/counter-lib

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test @fe-playground/counter-lib` to execute the unit tests via [Vitest](https://vitest.dev/).

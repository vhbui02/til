import { render } from '@testing-library/react';

import FePlaygroundSocialMediaLib from './social-media-lib';

describe('FePlaygroundSocialMediaLib', () => {
  it('should render successfully', () => {
    const { baseElement } = render(<FePlaygroundSocialMediaLib />);
    expect(baseElement).toBeTruthy();
  });
});

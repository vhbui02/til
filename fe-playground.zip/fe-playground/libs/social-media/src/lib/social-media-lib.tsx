import styles from './social-media-lib.module.css';

export function FePlaygroundSocialMediaLib() {
  return (
    <div className={styles['container']}>
      <h1>Welcome to FePlaygroundSocialMediaLib!</h1>
    </div>
  );
}

export default FePlaygroundSocialMediaLib;

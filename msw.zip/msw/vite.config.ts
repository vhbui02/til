/// <reference types="vitest" />
/// <reference types="vite/client" />
/// <reference types="vitest/config" />

import react from '@vitejs/plugin-react';
import path from 'node:path';
import { defineConfig } from 'vite';
import viteTsconfigPaths from 'vite-tsconfig-paths';
import packageJson from "./package.json" with { type: "json " };

export default defineConfig({
  base: './',
  plugins: [
    react(),
    viteTsconfigPaths() // make TS path aliases (like @/... ) worked in Vite
  ],
  server: {
    port: 3000,
  },
  preview: {
    port: 3000,
  },
  // CAUTION: 'test' will cause error if <reference types="vitest/config" /> is not specified
  test: {
    root: import.meta.dirname, // crucial in monorepo setup, redundant if already root
    name: packageJson.name,
    globals: true, // enable global test API, use API without 'import' syntax
    environment: 'jsdom', // run tests in a browser-like DOM environment, useful for UI Component test by RTL
    typecheck: {
      enabled: true,
      tsconfig: path.join(import.meta.dirname, "tsconfig.json"),
    },
    exclude: ['**/node_modules/**', '**/e2e/**'],
    coverage: {
      include: ['src/**'],
    },
    setupFiles: './src/testing/setup-tests.ts', // global mocks + test helpers
  },
  optimizeDeps: { exclude: ['fsevents'] },
  build: {
    // configure Rollup, the bundler solution Vite uses for builds 
    rollupOptions: {
      external: ['fs/promises'], // marks fs/promises as external, it won't be bundled into build output
      output: {
        experimentalMinChunkSize: 3500, // avoid very small chunks by setting a minimum chunk size threshold
      },
    },
  },
});
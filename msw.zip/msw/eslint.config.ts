import js from "@eslint/js";
import vitestPlugin from "@vitest/eslint-plugin";
import prettierConfig from "eslint-config-prettier/flat";
import checkFilePlugin from "eslint-plugin-check-file";
import importPlugin from "eslint-plugin-import";
import jsxA11yPlugin from "eslint-plugin-jsx-a11y";
import reactPlugin from "eslint-plugin-react";
import reactHooksPlugin from "eslint-plugin-react-hooks";
import reactRefreshPlugin from "eslint-plugin-react-refresh";
import { defineConfig } from "eslint/config";
import globals from "globals";
import tseslint from "typescript-eslint";

export default defineConfig([
  // Global ignores for dependencies, build output, caches, and generated files
  {
    name: "global-ignores",
    ignores: [
      "**/node_modules/**",
      "**/dist/**",
      "**/build/**",
      "**/coverage/**",
      "**/.yarn/**",
      "**/temp/**",
      "**/.temp/**",
      "**/tmp/**",
      "**/.tmp/**",
      "public/mockServiceWorker.js",
      "generators/**",
    ],
  },

  // @eslint/js
  js.configs.recommended,

  // typescript-eslint
  // ...tseslint.configs.recommended,
  ...tseslint.configs.strict,
  ...tseslint.configs.stylistic,

  // eslint-plugin-import
  importPlugin.flatConfigs.recommended,
  importPlugin.flatConfigs.typescript,
  importPlugin.flatConfigs.errors,
  importPlugin.flatConfigs.warnings,
  jsxA11yPlugin.flatConfigs.recommended,

  // base language options and shared settings
  {
    name: "language-options",
    files: ["**/*.{js,jsx,ts,tsx}"],
    languageOptions: {
      ecmaVersion: "latest",
      sourceType: "module",
      globals: {
        ...globals.browser,
        ...globals.node,
        ...globals.serviceworker,
      },
      parserOptions: {
        projectService: true,
        tsconfigRootDir: import.meta.dirname,
      },
    },
    settings: {
      react: {
        version: "detect" // instructs 'eslint-plugin-react' to auto-check your package.json to find the exact version of installed React, prevents warning about missing `import React from "react"` in React 17+ at the top of every file
      },
      "import/resolver": {
        typescript: {
          alwaysTryTypes: true, // always look for types under @types directory under node_modules, even if the package itself does not declare TypeScript support
          project: ['./tsconfig.base.json'], // allow ESLint to understand custom path aliases like `@/components/Button` defined inside that file so it does not throw a false `module not found` errors
        }
      },
      vitest: { typecheck: true },
    },
  },

  //
  {
    plugins: {
      "react-refresh": reactRefreshPlugin
    },
    rules: {
      'react-refresh/only-export-components': [
        'warn',
        { allowConstantExport: true }, // Allows exporting non-component constants safely
      ],
    }
  },

  // eslint-plugin-react & eslint-plugin-react-hooks & react-refresh
  {
    name: "react-configuration",
    // safely spread single-object flat configs into this scoped object
    ...reactPlugin.configs.flat.recommended,
    ...reactPlugin.configs.flat["jsx-runtime"],
    rules: {
      ...reactHooksPlugin.configs.recommended.rules,
      "react/prop-types": "off",
      "react/display-name": "off",
      "react/react-in-jsx-scope": 'off',
      'react/jsx-pascal-case': [
        'warn',
        {
          allowAllCaps: false, // Prevents names like <MYCOMPONENT />
          ignore: []           // Add specific allowed exceptions here if needed
        }
      ],
    },
  },

  // @vitest/eslint-plugin (scoped to test scripts)
  {
    name: "vitest-configuration",
    files: ["src/**/__tests__/**/*.{ts,tsx}"],
    plugins: {
      vitest: vitestPlugin,
    },
    rules: {
      ...vitestPlugin.configs.recommended.rules,
    },
  },

  {
    name: "custom-rules",
    rules: {
      // Prefer TS-aware no-unused-vars; disable base rule to avoid duplicate reports
      "no-unused-vars": "off",
      "@typescript-eslint/no-unused-vars": [
        "warn",
        {
          varsIgnorePattern: '^_',
          argsIgnorePattern: '^_',
        }
      ],
      // TS ergonomics
      "@typescript-eslint/no-explicit-any": "off",
      "@typescript-eslint/no-empty-function": "off",
      "@typescript-eslint/explicit-function-return-type": "off",
      "@typescript-eslint/explicit-module-boundary-types": "off",
      "@typescript-eslint/consistent-type-definitions": [2, "type"],
      "@typescript-eslint/consistent-type-imports": [
        2,
        {
          prefer: "type-imports",
          fixStyle: "separate-type-imports",
          disallowTypeAnnotations: true,
        },
      ],

      // allow anchor tags lack valid href= attribute or use placeholder link like href="#"
      "jsx-a11y/anchor-is-valid": "off",

      // Enforce the use of pre-typed versions
      "no-restricted-imports": [
        2,
        {
          paths: [
            {
              name: "react-redux",
              importNames: ["useSelector", "useStore", "useDispatch"],
              message: "Please use pre-typed versions instead.",
            },
          ],
        },
      ],

      // Feature boundaries and layering rules
      // "import/no-restricted-paths": [
      //   "error",
      //   {
      //     zones: [
      //       // disable cross-feature imports
      //       { target: "./src/features/auth", from: "./src/features", except: ["./auth"] },
      //       { target: "./src/features/comments", from: "./src/features", except: ["./comments"] },
      //       {
      //         target: "./src/features/discussions",
      //         from: "./src/features",
      //         except: ["./discussions"],
      //       },
      //       { target: "./src/features/teams", from: "./src/features", except: ["./teams"] },
      //       { target: "./src/features/users", from: "./src/features", except: ["./users"] },
      //       { target: "./src/features", from: "./src/app" },
      //       {
      //         target: [
      //           "./src/components",
      //           "./src/hooks",
      //           "./src/lib",
      //           "./src/types",
      //           "./src/utils",
      //         ],
      //         from: ["./src/features", "./src/app"],
      //       },
      //     ],
      //   },
      // ],

      "import/no-cycle": "error",
      // Disable noisy or redundant rules in TS + modern React setups
      "import/default": "off",
      "import/named": "off",
      "import/namespace": "off",
      "import/no-unresolved": "off",
      "import/no-named-as-default-member": "off",
      "import/no-named-as-default": "off",

      // Deterministic import ordering
      "import/order": [
        "error",
        {
          groups: [
            "builtin",
            "external",
            "internal",
            "parent",
            "sibling",
            "index",
            "object",
            "type",
          ],
          "newlines-between": "always",
          alphabetize: { order: "asc", caseInsensitive: true },
        },
      ],

      // Cross-platform consistency
      "linebreak-style": ["error", "unix"],
    }
  },

  // Naming convention
  {
    name: "files-naming-convention",
    files: ["src/**/*.{js,jsx,ts,tsx}"],
    plugins: {
      "check-file": checkFilePlugin,
    },
    rules: {
      "check-file/filename-naming-convention": [
        "error",
        {
          "**/*.{ts,tsx}": "KEBAB_CASE"
        },
        {
          ignoreMiddleExtensions: true
        },
      ],
    }
  },
  {
    name: "folder-naming-convention",
    files: ["src/**/!(__tests__)/*"],
    plugins: {
      "check-file": checkFilePlugin,
    },
    rules: {
      "check-file/folder-naming-convention": [
        "error",
        {
          "**/*": "KEBAB_CASE",
        },
      ],
    },
  },

  // last, disable formatting-conflicting rules
  prettierConfig,
]);
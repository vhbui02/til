This file is a merged representation of the entire codebase, combined into a single document by Repomix.
The content has been processed where empty lines have been removed.

# File Summary

## Purpose
This file contains a packed representation of the entire repository's contents.
It is designed to be easily consumable by AI systems for analysis, code review,
or other automated processes.

## File Format
The content is organized as follows:
1. This summary section
2. Repository information
3. Directory structure
4. Repository files (if enabled)
5. Multiple file entries, each consisting of:
  a. A header with the file path (## File: path/to/file)
  b. The full contents of the file in a code block

## Usage Guidelines
- This file should be treated as read-only. Any changes should be made to the
  original repository files, not this packed version.
- When processing this file, use the file path to distinguish
  between different files in the repository.
- Be aware that this file may contain sensitive information. Handle it with
  the same level of security as you would the original repository.

## Notes
- Some files may have been excluded based on .gitignore rules and Repomix's configuration
- Binary files are not included in this packed representation. Please refer to the Repository Structure section for a complete list of file paths, including binary files
- Files matching patterns in .gitignore are excluded
- Files matching default ignore patterns are excluded
- Empty lines have been removed from all files
- Files are sorted by Git change count (files with more changes are at the bottom)

# Directory Structure
```
public/
  mockServiceWorker.js
src/
  hooks/
    __tests__/
      use-demo.test.ts
    use-demo.ts
  testing/
    mocks/
      handlers/
        http.ts
      browser.ts
      handlers.ts
      index.ts
      server.ts
    setup-tests.ts
  types/
    api.ts
  App.tsx
  index.tsx
index.html
package.json
repomix.config.json
tsconfig.json
vite-env.d.ts
vite.config.ts
```

# Files

## File: public/mockServiceWorker.js
```javascript
/* eslint-disable */
/* tslint:disable */
/**
 * Mock Service Worker.
 * @see https://github.com/mswjs/msw
 * - Please do NOT modify this file.
 */
const PACKAGE_VERSION = '2.14.6'
const INTEGRITY_CHECKSUM = '4db4a41e972cec1b64cc569c66952d82'
const IS_MOCKED_RESPONSE = Symbol('isMockedResponse')
const activeClientIds = new Set()
addEventListener('install', function () {
  self.skipWaiting()
})
addEventListener('activate', function (event) {
  event.waitUntil(self.clients.claim())
})
addEventListener('message', async function (event) {
  const clientId = Reflect.get(event.source || {}, 'id')
  if (!clientId || !self.clients) {
    return
  }
  const client = await self.clients.get(clientId)
  if (!client) {
    return
  }
  const allClients = await self.clients.matchAll({
    type: 'window',
  })
  switch (event.data) {
    case 'KEEPALIVE_REQUEST': {
      sendToClient(client, {
        type: 'KEEPALIVE_RESPONSE',
      })
      break
    }
    case 'INTEGRITY_CHECK_REQUEST': {
      sendToClient(client, {
        type: 'INTEGRITY_CHECK_RESPONSE',
        payload: {
          packageVersion: PACKAGE_VERSION,
          checksum: INTEGRITY_CHECKSUM,
        },
      })
      break
    }
    case 'MOCK_ACTIVATE': {
      activeClientIds.add(clientId)
      sendToClient(client, {
        type: 'MOCKING_ENABLED',
        payload: {
          client: {
            id: client.id,
            frameType: client.frameType,
          },
        },
      })
      break
    }
    case 'CLIENT_CLOSED': {
      activeClientIds.delete(clientId)
      const remainingClients = allClients.filter((client) => {
        return client.id !== clientId
      })
      // Unregister itself when there are no more clients
      if (remainingClients.length === 0) {
        self.registration.unregister()
      }
      break
    }
  }
})
addEventListener('fetch', function (event) {
  const requestInterceptedAt = Date.now()
  // Bypass navigation requests.
  if (event.request.mode === 'navigate') {
    return
  }
  // Opening the DevTools triggers the "only-if-cached" request
  // that cannot be handled by the worker. Bypass such requests.
  if (
    event.request.cache === 'only-if-cached' &&
    event.request.mode !== 'same-origin'
  ) {
    return
  }
  // Bypass all requests when there are no active clients.
  // Prevents the self-unregistered worked from handling requests
  // after it's been terminated (still remains active until the next reload).
  if (activeClientIds.size === 0) {
    return
  }
  const requestId = crypto.randomUUID()
  event.respondWith(handleRequest(event, requestId, requestInterceptedAt))
})
/**
 * @param {FetchEvent} event
 * @param {string} requestId
 * @param {number} requestInterceptedAt
 */
async function handleRequest(event, requestId, requestInterceptedAt) {
  const client = await resolveMainClient(event)
  const requestCloneForEvents = event.request.clone()
  const response = await getResponse(
    event,
    client,
    requestId,
    requestInterceptedAt,
  )
  // Send back the response clone for the "response:*" life-cycle events.
  // Ensure MSW is active and ready to handle the message, otherwise
  // this message will pend indefinitely.
  if (client && activeClientIds.has(client.id)) {
    const serializedRequest = await serializeRequest(requestCloneForEvents)
    // Clone the response so both the client and the library could consume it.
    const responseClone = response.clone()
    sendToClient(
      client,
      {
        type: 'RESPONSE',
        payload: {
          isMockedResponse: IS_MOCKED_RESPONSE in response,
          request: {
            id: requestId,
            ...serializedRequest,
          },
          response: {
            type: responseClone.type,
            status: responseClone.status,
            statusText: responseClone.statusText,
            headers: Object.fromEntries(responseClone.headers.entries()),
            body: responseClone.body,
          },
        },
      },
      responseClone.body ? [serializedRequest.body, responseClone.body] : [],
    )
  }
  return response
}
/**
 * Resolve the main client for the given event.
 * Client that issues a request doesn't necessarily equal the client
 * that registered the worker. It's with the latter the worker should
 * communicate with during the response resolving phase.
 * @param {FetchEvent} event
 * @returns {Promise<Client | undefined>}
 */
async function resolveMainClient(event) {
  const client = await self.clients.get(event.clientId)
  if (activeClientIds.has(event.clientId)) {
    return client
  }
  if (client?.frameType === 'top-level') {
    return client
  }
  const allClients = await self.clients.matchAll({
    type: 'window',
  })
  return allClients
    .filter((client) => {
      // Get only those clients that are currently visible.
      return client.visibilityState === 'visible'
    })
    .find((client) => {
      // Find the client ID that's recorded in the
      // set of clients that have registered the worker.
      return activeClientIds.has(client.id)
    })
}
/**
 * @param {FetchEvent} event
 * @param {Client | undefined} client
 * @param {string} requestId
 * @param {number} requestInterceptedAt
 * @returns {Promise<Response>}
 */
async function getResponse(event, client, requestId, requestInterceptedAt) {
  // Clone the request because it might've been already used
  // (i.e. its body has been read and sent to the client).
  const requestClone = event.request.clone()
  function passthrough() {
    // Cast the request headers to a new Headers instance
    // so the headers can be manipulated with.
    const headers = new Headers(requestClone.headers)
    // Remove the "accept" header value that marked this request as passthrough.
    // This prevents request alteration and also keeps it compliant with the
    // user-defined CORS policies.
    const acceptHeader = headers.get('accept')
    if (acceptHeader) {
      const values = acceptHeader.split(',').map((value) => value.trim())
      const filteredValues = values.filter(
        (value) => value !== 'msw/passthrough',
      )
      if (filteredValues.length > 0) {
        headers.set('accept', filteredValues.join(', '))
      } else {
        headers.delete('accept')
      }
    }
    return fetch(requestClone, { headers })
  }
  // Bypass mocking when the client is not active.
  if (!client) {
    return passthrough()
  }
  // Bypass initial page load requests (i.e. static assets).
  // The absence of the immediate/parent client in the map of the active clients
  // means that MSW hasn't dispatched the "MOCK_ACTIVATE" event yet
  // and is not ready to handle requests.
  if (!activeClientIds.has(client.id)) {
    return passthrough()
  }
  // Notify the client that a request has been intercepted.
  const serializedRequest = await serializeRequest(event.request)
  const clientMessage = await sendToClient(
    client,
    {
      type: 'REQUEST',
      payload: {
        id: requestId,
        interceptedAt: requestInterceptedAt,
        ...serializedRequest,
      },
    },
    [serializedRequest.body],
  )
  switch (clientMessage.type) {
    case 'MOCK_RESPONSE': {
      return respondWithMock(clientMessage.data)
    }
    case 'PASSTHROUGH': {
      return passthrough()
    }
  }
  return passthrough()
}
/**
 * @param {Client} client
 * @param {any} message
 * @param {Array<Transferable>} transferrables
 * @returns {Promise<any>}
 */
function sendToClient(client, message, transferrables = []) {
  return new Promise((resolve, reject) => {
    const channel = new MessageChannel()
    channel.port1.onmessage = (event) => {
      if (event.data && event.data.error) {
        return reject(event.data.error)
      }
      resolve(event.data)
    }
    client.postMessage(message, [
      channel.port2,
      ...transferrables.filter(Boolean),
    ])
  })
}
/**
 * @param {Response} response
 * @returns {Response}
 */
function respondWithMock(response) {
  // Setting response status code to 0 is a no-op.
  // However, when responding with a "Response.error()", the produced Response
  // instance will have status code set to 0. Since it's not possible to create
  // a Response instance with status code 0, handle that use-case separately.
  if (response.status === 0) {
    return Response.error()
  }
  const mockedResponse = new Response(response.body, response)
  Reflect.defineProperty(mockedResponse, IS_MOCKED_RESPONSE, {
    value: true,
    enumerable: true,
  })
  return mockedResponse
}
/**
 * @param {Request} request
 */
async function serializeRequest(request) {
  return {
    url: request.url,
    mode: request.mode,
    method: request.method,
    headers: Object.fromEntries(request.headers.entries()),
    cache: request.cache,
    credentials: request.credentials,
    destination: request.destination,
    integrity: request.integrity,
    redirect: request.redirect,
    referrer: request.referrer,
    referrerPolicy: request.referrerPolicy,
    body: await request.arrayBuffer(),
    keepalive: request.keepalive,
  }
}
```

## File: src/hooks/__tests__/use-demo.test.ts
```typescript
test('should respond with the user list', async () => {
  const response = await fetch("http://localhost:3000/users");
  expect(response.status).toBe(200);
  await expect(response.json()).resolves.toEqual([{
    id: 1,
    firstName: "Silver",
    lastName: "Wick",
  }]);
});
test('should respond with a single user', async () => {
  const response = await fetch("http://localhost:3000/users/1");
  expect(response.status).toBe(200);
  await expect(response.json()).resolves.toEqual({
    id: 1,
    firstName: "Silver",
    lastName: "Wick",
  });
});
test('should respond with invalid message', async () => {
  const response = await fetch("http://localhost:3000/users/abc");
  await expect(response.json()).resolves.toEqual({
    message: "Invalid ID format provided.",
    status: 400,
  });
});
test('should respond with a product when id query param is provided', async () => {
  // Pass the id as a search parameter in the URL
  const response = await fetch("http://localhost:3000/products?id=1");
  expect(response.status).toBe(200);
  await expect(response.json()).resolves.toEqual({
    id: 1,
    name: "Twisting Chair"
  });
});
test('should respond with 404 Not Found when id query param is missing', async () => {
  const response = await fetch("http://localhost:3000/products");
  expect(response.status).toBe(404);
  // NOTE: Since the response body is null, attempting to call response.json() 
  // here would throw a parsing error, so we just check the status code.
});
```

## File: src/hooks/use-demo.ts
```typescript

```

## File: src/testing/mocks/handlers/http.ts
```typescript
// support: http, graphql, sse, websockets
import type { User } from "@/types/api";
import { http, HttpResponse } from 'msw';
import { request } from "node:http";
/* 
  Benefits:
  - Client-agnostic: MSW intercepts any HTTP requests, regardless of the request client (e.g., fetch, Axios, React Query, ...)
  - Seamless: handle on network-level, require zero changes to the SUT.
  - Reusable: use the same mocks for different purposes: local development (or just rely on and wait for shared BE), automated testing, debugging, demo
  - Type-safe: add up-to-date types to path parameters, request/response body, ...
*/
export const httpHandlers = [
  // this is a "request handler"
  // syntax: http.get<PathParams, ...>(predicate, resolver, options?)
  http.get('/users', () => {
    return HttpResponse.json([{
      id: 1,
      firstName: "Silver",
      lastName: "Wick",
    }]);
  }),
  http.get<{ id: string; }>("/users/:id", ({ params }) => {
    const { id: userId } = params;
    console.log(`Fetching user with id ${userId} ...`);
    const parsedId = +userId; // unary operator
    if (isNaN(parsedId)) {
      return HttpResponse.json(
        {
          message: "Invalid ID format provided.",
          status: 400,
        }
      );
    }
    return HttpResponse.json({
      id: parsedId,
      firstName: "Silver",
      lastName: "Wick",
    });
  }),
  http.get<{ id?: string; }>("/posts/:id", ({ params }) => {
    const { id: userId } = params;
    if (userId === undefined) {
      return new HttpResponse(null, {
        status: 400,
      });
    }
    console.log(`Fetching user with id ${userId} ...`);
    return HttpResponse.json({
      id: +userId, // unary plus
      firstName: "Silver",
      lastName: "Wick",
    });
  }),
  // repeating path parameters
  http.get<{ segments: string[]; }>('/settings/:segments+', ({ params }) => {
    console.log(params.segments);
  }),
  // single-value query parameter
  http.get('/products', ({ request }) => {
    const url = new URL(request.url);
    // Given a request URL of /products?id=1
    // the 'productId' will be "1" string
    const productId = url.searchParams.get("id");
    if (!productId) {
      return new HttpResponse(null, {
        status: 404,
      });
    }
    return HttpResponse.json({
      id: +productId,
      name: "Twisting Chair"
    });
  }),
  // multi-value query parameters
  http.get('/tests', ({ request }) => {
    const url = new URL(request.url);
    // Given a request url of "/products?id=1&id=2&id=3",
    // the `productIds` will be an array of ["1", "2", "3"].
    const productIds = url.searchParams.getAll('id');
    console.log(productIds);
  }),
  // http.post<Params, RequestBody, ResponseBody, Path>(path, resolver)
  http.post<{ id: string; }, User>("/users/:id", async ({ request }) => {
    // NOTE: highly recommended to clone the intercepted request before reading its body
    // NOTE: in passthrough/bypass scenarios, read without cloning will result in an exception (since streams cannot be read twice)
    const newUser = await request.clone().json();
    console.log(newUser);
  })
];
```

## File: src/testing/mocks/browser.ts
```typescript
import { setupWorker } from 'msw/browser';
import { handlers } from './handlers';
export const worker = setupWorker(...handlers);
```

## File: src/testing/mocks/handlers.ts
```typescript
import { httpHandlers } from "@/testing/mocks/handlers/http";
export const handlers = [
  ...httpHandlers,
];
```

## File: src/testing/mocks/index.ts
```typescript
export const enableMocking = async () => {
  if (process.env.NODE_ENV !== "development") {
    return;
  }
  const { worker } = await import("./browser");
  // `worker.start()` returns a Promise that resolves
  // once the Service Worker is up and ready to intercept requests.
  return worker.start();
};
```

## File: src/testing/mocks/server.ts
```typescript
import { setupServer } from 'msw/node';
import { handlers } from "./handlers";
// node.js processes, server-side environments, ...
// interception layer: class/module patching via @mswjs/interceptors to hook into http, https, fetch, XMLHttpRequest
// network visibility: Node network calls are caught seamlessly inside OS process lifecycle, no browser UI
// scope restrictions: global across the execution scope of the entire active Node.js thread
export const server = setupServer(...handlers);
```

## File: src/testing/setup-tests.ts
```typescript
import { server } from "@/testing/mocks/server";
beforeAll(() => server.listen({
  onUnhandledRequest: "error"
}));
afterAll(() => server.close());
beforeEach(() => { });
afterEach(() => server.resetHandlers());
```

## File: src/types/api.ts
```typescript
export type BaseEntity = {
  id: string;
  createdAt: string;
  updatedAt: string;
};
export type Entity<T> = {
  [K in keyof T]: T[K] // create a shallow copy of T, readonly is NOT preserved
} & BaseEntity;
export type Meta = {
  page: number;
  total: number;
  totalPages: number;
};
export type User = Entity<{
  firstName: string;
  lastName: string;
  email: string;
}>;
```

## File: src/App.tsx
```typescript
type Props = {};
export const App: React.FC<Props> = () => {
    return (
        <div>This is App component</div>
    );
};
```

## File: src/index.tsx
```typescript
import { enableMocking } from "@/testing/mocks";
import React from "react";
import { createRoot } from 'react-dom/client';
import { App } from "./App";
const root = document.getElementById('root');
if (!root) {
  throw new Error("No root element found!");
}
// always await worker.start() promise
// Service Worker registration is asynchronous. If it failed to await, it may result in a race condition between the worker registration and the initial requests the app made
enableMocking().then(() => {
  createRoot(root).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
});
```

## File: index.html
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MSW Playground</title>
</head>
<body>
  <div id="root"></div>
  <script type="module" src="/src/index.tsx"></script>
</body>
</html>
```

## File: package.json
```json
{
  "name": "msw-playground",
  "version": "1.0.0",
  "private": true,
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build --base=/",
    "preview": "view preview",
    "test": "vitest"
  },
  "devDependencies": {
    "@types/jest": "^30.0.0",
    "@types/react": "^19.2.17",
    "@types/react-dom": "^19.2.3",
    "@vitejs/plugin-react": "^4.7.0",
    "jsdom": "^29.1.1",
    "msw": "^2.14.6",
    "ts-jest": "^29.4.11",
    "vite-tsconfig-paths": "^6.1.1",
    "vitest": "^4.1.9"
  },
  "dependencies": {
    "react": "^19.2.7",
    "react-dom": "^19.2.7"
  },
  "msw": {
    "workerDirectory": [
      "public"
    ]
  }
}
```

## File: repomix.config.json
```json
{
  "$schema": "https://repomix.com/schemas/latest/schema.json",
  "input": {
    "maxFileSize": 52428800
  },
  "output": {
    "filePath": ".tmp/repomix-output.md",
    "style": "markdown",
    "parsableStyle": false,
    "fileSummary": true,
    "directoryStructure": true,
    "files": true,
    "removeComments": false,
    "removeEmptyLines": true,
    "compress": false,
    "topFilesLength": 5,
    "showLineNumbers": false,
    "truncateBase64": false,
    "copyToClipboard": false,
    "includeFullDirectoryStructure": true,
    "tokenCountTree": true,
    "git": {
      "sortByChanges": true,
      "sortByChangesMaxCommits": 100,
      "includeDiffs": false,
      "includeLogs": false,
      "includeLogsCount": 50
    }
  },
  "include": [],
  "ignore": {
    "useGitignore": true,
    "useDotIgnore": true,
    "useDefaultPatterns": true,
    "customPatterns": []
  },
  "security": {
    "enableSecurityCheck": true
  },
  "tokenCount": {
    "encoding": "o200k_base"
  }
}
```

## File: tsconfig.json
```json
{
  "compilerOptions": {
    // Cre: https://github.com/alan2207/bulletproof-react/blob/master/apps/react-vite/tsconfig.json
    "target": "ESNext",
    "lib": [
      "dom",
      "dom.iterable",
      "esnext"
    ],
    // "allowJs": true,
    "skipLibCheck": true,
    "esModuleInterop": true,
    "allowSyntheticDefaultImports": true,
    "strict": true,
    "forceConsistentCasingInFileNames": true,
    "noFallthroughCasesInSwitch": true,
    "module": "esnext",
    "moduleResolution": "bundler", // this project use Vite, a build tool
    "resolveJsonModule": true,
    "noEmit": true,
    "jsx": "react-jsx",
    // load ambient type packages
    // - making types available globally in the project 
    // - limit the pulling of TypeScript to those type packages instead of pulling every visible @types package by default
    "types": [
      "vite/client", // can be removed if vite-env.d.ts is specified
      "vitest/globals" // add Vitest's global test helpers, dev can use "describe", "it", "expect", "beforeEach" without importing them
    ],
    "isolatedModules": true,
    // "baseUrl": ".", // CAUTION: depreciated in TypeScript v7.0: https://github.com/microsoft/TypeScript/issues/62207#issue-3293908272
    "paths": {
      "@/*": [
        "./src/*"
      ]
    },
    // Cre: https://blog.webdevsimplified.com/2026-04/advanced-tsconfig-settings/
    // Must Have
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "allowUnusedLabels": false,
    "allowUnreachableCode": false,
    // Optional (highly suggested)
    "noUncheckedIndexedAccess": true,
    //"noPropertyAccessFromIndexSignature": true, // e.g., process.env["NODE_ENV"]
    "erasableSyntaxOnly": true,
    // Personal preference
    "noImplicitOverride": true,
    "exactOptionalPropertyTypes": true,
  },
  "include": [
    "src",
    "vite.config.ts",
  ],
  "exclude": [
    "node_modules"
  ]
}
```

## File: vite-env.d.ts
```typescript
/// <reference types="vite/client" />
```

## File: vite.config.ts
```typescript
/// <reference types="vitest" />
/// <reference types="vite/client" />
/// <reference types="vitest/config" />
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';
import viteTsconfigPaths from 'vite-tsconfig-paths';
export default defineConfig({
  base: './',
  plugins: [
    react(),
    // make TS path aliases (like @/... ) worked in Vite
    viteTsconfigPaths()
  ],
  server: {
    port: 3000,
  },
  preview: {
    port: 3000,
  },
  // CAUTION: 'test' will cause error if <reference types="vitest/config" /> is not specified
  test: {
    globals: true, // enable global test API, use API without import
    environment: 'jsdom', // run tests in a browser-like DOM environment, useful for Component test
    setupFiles: './src/testing/setup-tests.ts', // global mocks + test helpers
    exclude: ['**/node_modules/**', '**/e2e/**'], // prevents Vitest from scanning node_modules or E2E test files
    coverage: {
      include: ['src/**'],
    },
  },
  optimizeDeps: { exclude: ['fsevents'] },
  build: {
    // configure Rollup, the bundler solution Vite uses for builds 
    rollupOptions: {
      external: ['fs/promises'], // marks fs/promises as external, it won't be bundled into build output
      output: {
        experimentalMinChunkSize: 3500, // avoid very small chunks by setting a minimum chunk size threshold
      },
    },
  },
});
```

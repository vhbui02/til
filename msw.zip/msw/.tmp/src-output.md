This file is a merged representation of the entire codebase, combined into a single document by Repomix.
The content has been processed where empty lines have been removed.

# File Summary

## Purpose
This file contains a packed representation of the entire repository's contents.
It is designed to be easily consumable by AI systems for analysis, code review,
or other automated processes.

## File Format
The content is organized as follows:
1. This summary section
2. Repository information
3. Directory structure
4. Repository files (if enabled)
5. Multiple file entries, each consisting of:
  a. A header with the file path (## File: path/to/file)
  b. The full contents of the file in a code block

## Usage Guidelines
- This file should be treated as read-only. Any changes should be made to the
  original repository files, not this packed version.
- When processing this file, use the file path to distinguish
  between different files in the repository.
- Be aware that this file may contain sensitive information. Handle it with
  the same level of security as you would the original repository.

## Notes
- Some files may have been excluded based on .gitignore rules and Repomix's configuration
- Binary files are not included in this packed representation. Please refer to the Repository Structure section for a complete list of file paths, including binary files
- Files matching patterns in .gitignore are excluded
- Files matching default ignore patterns are excluded
- Empty lines have been removed from all files
- Files are sorted by Git change count (files with more changes are at the bottom)

# Directory Structure
```
hooks/
  __tests__/
    use-demo.test.ts
  use-demo.ts
testing/
  mocks/
    handlers/
      http.ts
    browser.ts
    handlers.ts
    index.ts
    server.ts
  setup-tests.ts
types/
  api.ts
App.tsx
index.tsx
```

# Files

## File: hooks/__tests__/use-demo.test.ts
```typescript
test('should respond with the user list', async () => {
  const response = await fetch("http://localhost:3000/users");
  expect(response.status).toBe(200);
  await expect(response.json()).resolves.toEqual([{
    id: 1,
    firstName: "Silver",
    lastName: "Wick",
  }]);
});
test('should respond with a single user', async () => {
  const response = await fetch("http://localhost:3000/users/1");
  expect(response.status).toBe(200);
  await expect(response.json()).resolves.toEqual({
    id: 1,
    firstName: "Silver",
    lastName: "Wick",
  });
});
test('should respond with invalid message', async () => {
  const response = await fetch("http://localhost:3000/users/abc");
  await expect(response.json()).resolves.toEqual({
    message: "Invalid ID format provided.",
    status: 400,
  });
});
test('should respond with a product when id query param is provided', async () => {
  // Pass the id as a search parameter in the URL
  const response = await fetch("http://localhost:3000/products?id=1");
  expect(response.status).toBe(200);
  await expect(response.json()).resolves.toEqual({
    id: 1,
    name: "Twisting Chair"
  });
});
test('should respond with 404 Not Found when id query param is missing', async () => {
  const response = await fetch("http://localhost:3000/products");
  expect(response.status).toBe(404);
  // NOTE: Since the response body is null, attempting to call response.json() 
  // here would throw a parsing error, so we just check the status code.
});
```

## File: hooks/use-demo.ts
```typescript

```

## File: testing/mocks/handlers/http.ts
```typescript
// support: http, graphql, sse, websockets
import type { User } from "@/types/api";
import { http, HttpResponse } from 'msw';
import { request } from "node:http";
/* 
  Benefits:
  - Client-agnostic: MSW intercepts any HTTP requests, regardless of the request client (e.g., fetch, Axios, React Query, ...)
  - Seamless: handle on network-level, require zero changes to the SUT.
  - Reusable: use the same mocks for different purposes: local development (or just rely on and wait for shared BE), automated testing, debugging, demo
  - Type-safe: add up-to-date types to path parameters, request/response body, ...
*/
export const httpHandlers = [
  // this is a "request handler"
  // syntax: http.get<PathParams, ...>(predicate, resolver, options?)
  http.get('/users', () => {
    return HttpResponse.json([{
      id: 1,
      firstName: "Silver",
      lastName: "Wick",
    }]);
  }),
  http.get<{ id: string; }>("/users/:id", ({ params }) => {
    const { id: userId } = params;
    console.log(`Fetching user with id ${userId} ...`);
    const parsedId = +userId; // unary operator
    if (isNaN(parsedId)) {
      return HttpResponse.json(
        {
          message: "Invalid ID format provided.",
          status: 400,
        }
      );
    }
    return HttpResponse.json({
      id: parsedId,
      firstName: "Silver",
      lastName: "Wick",
    });
  }),
  http.get<{ id?: string; }>("/posts/:id", ({ params }) => {
    const { id: userId } = params;
    if (userId === undefined) {
      return new HttpResponse(null, {
        status: 400,
      });
    }
    console.log(`Fetching user with id ${userId} ...`);
    return HttpResponse.json({
      id: +userId, // unary plus
      firstName: "Silver",
      lastName: "Wick",
    });
  }),
  // repeating path parameters
  http.get<{ segments: string[]; }>('/settings/:segments+', ({ params }) => {
    console.log(params.segments);
  }),
  // single-value query parameter
  http.get('/products', ({ request }) => {
    const url = new URL(request.url);
    // Given a request URL of /products?id=1
    // the 'productId' will be "1" string
    const productId = url.searchParams.get("id");
    if (!productId) {
      return new HttpResponse(null, {
        status: 404,
      });
    }
    return HttpResponse.json({
      id: +productId,
      name: "Twisting Chair"
    });
  }),
  // multi-value query parameters
  http.get('/tests', ({ request }) => {
    const url = new URL(request.url);
    // Given a request url of "/products?id=1&id=2&id=3",
    // the `productIds` will be an array of ["1", "2", "3"].
    const productIds = url.searchParams.getAll('id');
    console.log(productIds);
  }),
  // http.post<Params, RequestBody, ResponseBody, Path>(path, resolver)
  http.post<{ id: string; }, User>("/users/:id", async ({ request }) => {
    // NOTE: highly recommended to clone the intercepted request before reading its body
    // NOTE: in passthrough/bypass scenarios, read without cloning will result in an exception (since streams cannot be read twice)
    const newUser = await request.clone().json();
    console.log(newUser);
  })
];
```

## File: testing/mocks/browser.ts
```typescript
import { setupWorker } from 'msw/browser';
import { handlers } from './handlers';
export const worker = setupWorker(...handlers);
```

## File: testing/mocks/handlers.ts
```typescript
import { httpHandlers } from "@/testing/mocks/handlers/http";
export const handlers = [
  ...httpHandlers,
];
```

## File: testing/mocks/index.ts
```typescript
export const enableMocking = async () => {
  if (process.env.NODE_ENV !== "development") {
    return;
  }
  const { worker } = await import("./browser");
  // `worker.start()` returns a Promise that resolves
  // once the Service Worker is up and ready to intercept requests.
  return worker.start();
};
```

## File: testing/mocks/server.ts
```typescript
import { setupServer } from 'msw/node';
import { handlers } from "./handlers";
// node.js processes, server-side environments, ...
// interception layer: class/module patching via @mswjs/interceptors to hook into http, https, fetch, XMLHttpRequest
// network visibility: Node network calls are caught seamlessly inside OS process lifecycle, no browser UI
// scope restrictions: global across the execution scope of the entire active Node.js thread
export const server = setupServer(...handlers);
```

## File: testing/setup-tests.ts
```typescript
import { server } from "@/testing/mocks/server";
beforeAll(() => server.listen({
  onUnhandledRequest: "error"
}));
afterAll(() => server.close());
beforeEach(() => { });
afterEach(() => server.resetHandlers());
```

## File: types/api.ts
```typescript
export type BaseEntity = {
  id: string;
  createdAt: string;
  updatedAt: string;
};
export type Entity<T> = {
  [K in keyof T]: T[K] // create a shallow copy of T, readonly is NOT preserved
} & BaseEntity;
export type Meta = {
  page: number;
  total: number;
  totalPages: number;
};
export type User = Entity<{
  firstName: string;
  lastName: string;
  email: string;
}>;
```

## File: App.tsx
```typescript
type Props = {};
export const App: React.FC<Props> = () => {
    return (
        <div>This is App component</div>
    );
};
```

## File: index.tsx
```typescript
import { enableMocking } from "@/testing/mocks";
import React from "react";
import { createRoot } from 'react-dom/client';
import { App } from "./App";
const root = document.getElementById('root');
if (!root) {
  throw new Error("No root element found!");
}
// always await worker.start() promise
// Service Worker registration is asynchronous. If it failed to await, it may result in a race condition between the worker registration and the initial requests the app made
enableMocking().then(() => {
  createRoot(root).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
});
```


test('should respond with the user list', async () => {
  const response = await fetch("http://localhost:3000/users");
  expect(response.status).toBe(200);
  await expect(response.json()).resolves.toEqual([{
    id: 1,
    firstName: "Silver",
    lastName: "Wick",
  }]);
});

test('should respond with a single user', async () => {
  const response = await fetch("http://localhost:3000/users/1");
  expect(response.status).toBe(200);
  await expect(response.json()).resolves.toEqual({
    id: 1,
    firstName: "Silver",
    lastName: "Wick",
  });
});

test('should respond with invalid message', async () => {
  const response = await fetch("http://localhost:3000/users/abc");
  await expect(response.json()).resolves.toEqual({
    message: "Invalid ID format provided.",
    status: 400,
  });
});

test('should respond with a product when id query param is provided', async () => {
  // Pass the id as a search parameter in the URL
  const response = await fetch("http://localhost:3000/products?id=1");

  expect(response.status).toBe(200);
  await expect(response.json()).resolves.toEqual({
    id: 1,
    name: "Twisting Chair"
  });
});

test('should respond with 404 Not Found when id query param is missing', async () => {
  const response = await fetch("http://localhost:3000/products");
  expect(response.status).toBe(404);

  // NOTE: Since the response body is null, attempting to call response.json() 
  // here would throw a parsing error, so we just check the status code.
});
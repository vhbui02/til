import type { AppDispatch, RootState } from "@/app/store.ts";
import { useDispatch, useSelector } from "react-redux";

// now dispatch() callback result from useAppDispatch() invocation will have type inference
export const useAppDispatch = useDispatch.withTypes<AppDispatch>();

// avoid having to define (state: RootState) to every selector callback
export const useAppSelector = useSelector.withTypes<RootState>();

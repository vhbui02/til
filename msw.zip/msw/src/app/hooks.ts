import type { AppDispatch, RootState } from "@/app/store.ts";
import { useDispatch, useSelector } from "react-redux";

// setup pre-typed version of common hooks
export const useAppDispatch = useDispatch.withTypes<AppDispatch>();
export const useAppSelector = useSelector.withTypes<RootState>();

import type { AppDispatch, RootState } from "@/app/store.ts";
import type { client } from "@/libs/api-client.ts";
import { createAsyncThunk } from "@reduxjs/toolkit";

export const createAppAsyncThunk = createAsyncThunk.withTypes<{
  state: RootState;
  dispatch: AppDispatch;
  extra: {
    api: typeof client;
  };
}>();

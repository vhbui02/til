import type { AppDispatch, RootState } from "@/app/store.ts";
import { addPostListeners } from "@/features/posts/postsSlice.ts";
import { addListener, createListenerMiddleware } from "@reduxjs/toolkit";

export const listenerMiddleware = createListenerMiddleware();

export const startAppListening = listenerMiddleware.startListening.withTypes<
  RootState,
  AppDispatch
>();
export type AppStartListening = typeof startAppListening;

// setup pre-typed version
export const addAppListener = addListener.withTypes<RootState, AppDispatch>();
export type AppAddListener = typeof addAppListener;

// listener file import and run setup function who import the type from listener file.
// TIPS: this is safe DI
addPostListeners(startAppListening);

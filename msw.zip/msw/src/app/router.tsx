import { Counter } from "@/features/counter/Counter.tsx";
import { createBrowserRouter } from "react-router";
import { RouterProvider } from "react-router/dom";

const router = createBrowserRouter([
  {
    path: "/counter",
    element: <Counter />,
  },
  {
    path: "/social-media",
    element: <SocialMedia />,
  },
]);

export const AppRouter = () => {
  return <RouterProvider router={router} />;
};

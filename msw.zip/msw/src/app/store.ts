import counterReducer from "@/features/counter/counterSlice.ts";
import type { Action, ThunkAction } from "@reduxjs/toolkit";
import { configureStore } from "@reduxjs/toolkit";

// some internal middleware are setup
// Redux DevTools Extension to inspect the contents
export const store = configureStore({
  reducer: {
    // app made up of many different features,
    // each of the feature have its own reducer function
    // "I want to have a `state.counter` section of the Redux state object"
    counter: counterReducer
  }
});


export type AppStore = typeof store;
export type RootState = ReturnType<AppStore["getState"]>;
export type AppDispatch = AppStore["dispatch"];
export type AppThunk<ThunkReturnType = void> = ThunkAction<
  ThunkReturnType,
  RootState,
  unknown,
  Action
>;
import { listenerMiddleware } from "@/app/listenerMiddleware";
import { authReducer } from "@/features/auth/authSlice.ts";
import counterReducer from "@/features/counter/counterSlice.ts";
import { notificationsReducer } from "@/features/notifications/notificationSlice.ts";
import { postsReducer } from "@/features/posts/postsSlice";
import { usersReducer } from "@/features/users/usersSlice.ts";
import { client } from "@/libs/api-client.ts";
import type { Action, ThunkAction } from "@reduxjs/toolkit";
import { configureStore } from "@reduxjs/toolkit";

// NOTE: THERE MUST BE ONE STORE INSTANCE FOR AN ENTIRE APPLICATION
// NOTE: NEVER IMPORT THE STORE INTO OTHER COMPONENTS
export const store = configureStore({
  reducer: {
    // An app is made up of many different features,
    // Each feature has its own reducer function
    counter: counterReducer, // create a "state.counter" property
    posts: postsReducer,
    users: usersReducer,
    auth: authReducer,
    notifications: notificationsReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      thunk: {
        extraArgument: {
          // DI, passed external tools (e.g., API client, analytics service, logging utility) into thunks without importing it directly at the top of the file
          // extremely useful for testing
          // NOTE: remember to add type to "createAppAsyncThunk"
          api: client,
        },
      },
    }).prepend(
      // order matters! listener middleware needs to be at the start of the pipeline in order to intercept actions
      listenerMiddleware.middleware,
    ),
});

export type AppStore = typeof store;
export type RootState = ReturnType<AppStore["getState"]>; // or ReturnType<typeof store.getState>
export type AppDispatch = AppStore["dispatch"]; // or typeof store.dispatch
export type AppThunk<ThunkReturnType = void> = ThunkAction<
  ThunkReturnType,
  RootState,
  unknown,
  Action
>;

// NOTE: anything put within src/app/ are application-wide setup and configuration

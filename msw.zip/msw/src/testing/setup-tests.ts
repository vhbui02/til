import { server } from "@/testing/mocks/server";

beforeAll(() => server.listen({
  onUnhandledRequest: "error"
}));
afterAll(() => server.close());

beforeEach(() => { });
afterEach(() => server.resetHandlers());
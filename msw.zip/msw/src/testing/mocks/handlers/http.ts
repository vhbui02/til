// support: http, graphql, sse, websockets
import type { User } from "@/types/api";
import { http, HttpResponse } from "msw";
import { request } from "node:http";

/* 
  Benefits:
  - Client-agnostic: MSW intercepts any HTTP requests, regardless of the request client (e.g., fetch, Axios, React Query, ...)
  - Seamless: handle on network-level, require zero changes to the SUT.
  - Reusable: use the same mocks for different purposes: local development (or just rely on and wait for shared BE), automated testing, debugging, demo
  - Type-safe: add up-to-date types to path parameters, request/response body, ...
*/
export const httpHandlers = [
  // this is a "request handler"
  // syntax: http.get<PathParams, ...>(predicate, resolver, options?)
  http.get("/users", () => {
    return HttpResponse.json([
      {
        id: 1,
        firstName: "Silver",
        lastName: "Wick",
      },
    ]);
  }),

  http.get<{ id: string }>("/users/:id", ({ params }) => {
    const { id: userId } = params;
    console.log(`Fetching user with id ${userId} ...`);

    const parsedId = +userId; // unary operator
    if (isNaN(parsedId)) {
      return HttpResponse.json({
        message: "Invalid ID format provided.",
        status: 400,
      });
    }

    return HttpResponse.json({
      id: parsedId,
      firstName: "Silver",
      lastName: "Wick",
    });
  }),

  http.get<{ id?: string }>("/posts/:id", ({ params }) => {
    const { id: userId } = params;
    if (userId === undefined) {
      return new HttpResponse(null, {
        status: 400,
      });
    }

    console.log(`Fetching user with id ${userId} ...`);

    return HttpResponse.json({
      id: +userId, // unary plus
      firstName: "Silver",
      lastName: "Wick",
    });
  }),

  // repeating path parameters
  http.get<{ segments: string[] }>("/settings/:segments+", ({ params }) => {
    console.log(params.segments);
  }),

  // single-value query parameter
  http.get("/products", ({ request }) => {
    const url = new URL(request.url);

    // Given a request URL of /products?id=1
    // the 'productId' will be "1" string
    const productId = url.searchParams.get("id");
    if (!productId) {
      return new HttpResponse(null, {
        status: 404,
      });
    }

    return HttpResponse.json({
      id: +productId,
      name: "Twisting Chair",
    });
  }),

  // multi-value query parameters
  http.get("/tests", ({ request }) => {
    const url = new URL(request.url);

    // Given a request url of "/products?id=1&id=2&id=3",
    // the `productIds` will be an array of ["1", "2", "3"].
    const productIds = url.searchParams.getAll("id");
    console.log(productIds);
  }),

  // http.post<Params, RequestBody, ResponseBody, Path>(path, resolver)
  http.post<{ id: string }, User>("/users/:id", async ({ request }) => {
    // NOTE: highly recommended to clone the intercepted request before reading its body
    // NOTE: in passthrough/bypass scenarios, read without cloning will result in an exception (since streams cannot be read twice)
    const newUser = await request.clone().json();
    console.log(newUser);
  }),
];

import { useAppSelector } from "@/app/hooks.ts";
import { Navbar } from "@/components/Navbar.tsx";
import { selectCurrentUserID } from "@/features/auth/authSlice.ts";
import { LoginPage } from "@/features/auth/LoginPage.tsx";
import { Counter } from "@/features/counter/Counter.tsx";
import { NotificationsList } from "@/features/notifications/NotificationsList.tsx";
import { EditPostForm } from "@/features/posts/EditPostForm.tsx";
import { PostsMainPage } from "@/features/posts/PostsMainPage";
import { SinglePostPage } from "@/features/posts/SinglePostPage";
import { UserPage } from "@/features/users/UserPage.tsx";
import { UsersList } from "@/features/users/UsersList.tsx";
import React from "react";
import { BrowserRouter, Navigate, Route, Routes } from "react-router";

const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const username = useAppSelector(selectCurrentUserID);

  if (username === null) {
    return <Navigate to={"/social-media/login"} replace />;
  }

  return children;
};

export const App = () => {
  return (
    <BrowserRouter>
      <Navbar />
      <div className="App">
        <Routes>
          <Route
            path="/counter"
            element={
              <>
                <Counter />
              </>
            }
          />

          <Route path="/social-media" element={<LoginPage />} />
          <Route
            path="/social-media/*"
            element={
              <ProtectedRoute>
                <Route path="/social-media/posts" element={<PostsMainPage />} />
                <Route
                  path="/social-media/posts/:postId"
                  element={<SinglePostPage />}
                />
                <Route
                  path="/social-media/posts/:postId/actions/edit"
                  element={<EditPostForm />}
                />
                <Route path="/social-media/users" element={<UsersList />} />
                <Route
                  path="/social-media/users/:userId"
                  element={<UserPage />}
                />
                <Route
                  path="/social-media/notifications"
                  element={<NotificationsList />}
                />
              </ProtectedRoute>
            }
          />
        </Routes>
      </div>
    </BrowserRouter>
  );
};

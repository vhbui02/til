
type Props = {};

export const App: React.FC<Props> = () => {
    return (
        <div>This is App component</div>
    );
};
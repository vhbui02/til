import { store } from "@/app/store.ts";
import { enableMocking } from "@/testing/mocks";
import { StrictMode } from "react";
import { createRoot } from 'react-dom/client';
import { Provider } from "react-redux";
import { App } from "./App";

const container = document.getElementById('root');
if (!container) {
  throw new Error("Root element with ID 'root' was not found in the document. Ensure there is a corresponding HTML element with the ID 'root' in your HTML file.");
}

// always await worker.start() promise
// Service Worker registration is asynchronous. If it failed to await, it may result in a race condition between the worker registration and the initial requests the app made
enableMocking().then(() => {
  const root = createRoot(container)
  root.render(
    <StrictMode>
      <Provider store={store}>
        <App />
      </Provider>
    </StrictMode>
  );
});
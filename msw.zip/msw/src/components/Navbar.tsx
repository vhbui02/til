import { useAppDispatch, useAppSelector } from "@/app/hooks.ts";
import { UserIcon } from "@/components/UserIcon.tsx";
import { logout } from "@/features/auth/authSlice.ts";
import {
  fetchNotifications,
  selectUnreadNotificationsCount,
} from "@/features/notifications/notificationSlice.ts";
// import { userLoggedOut } from "@/features/auth/authSlice.ts";
import { selectCurrentUser } from "@/features/users/usersSlice.ts";
import { Link } from "react-router";

export const Navbar = () => {
  const dispatch = useAppDispatch();
  const user = useAppSelector(selectCurrentUser);
  const isLoggedIn = !!user;
  const numUnreadNotifications = useAppSelector(selectUnreadNotificationsCount);

  return (
    <nav>
      <section>
        <h1>Redux Essentials Example</h1>
        {isLoggedIn && (
          <div className="navContent">
            <div className="navLinks">
              <Link to="/counter">Counter</Link>
              <Link to="/social-media/posts">Posts</Link>
              <Link to="/social-media/users">Users</Link>
              <Link to="/social-media/notifications">
                Notifications{" "}
                {numUnreadNotifications > 0 ? (
                  <span className="badge">{numUnreadNotifications}</span>
                ) : null}
              </Link>
              <button
                className="button small"
                onClick={() => {
                  dispatch(fetchNotifications());
                }}
              >
                Refresh Notifications
              </button>
            </div>
            <div className="userDetails">
              <UserIcon size={32} />
              {user.name}
              <button
                className="button small"
                onClick={() => {
                  dispatch(logout());
                }}
              >
                Log Out
              </button>
            </div>
          </div>
        )}
      </section>
    </nav>
  );
};

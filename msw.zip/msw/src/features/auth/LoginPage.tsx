import { useAppDispatch, useAppSelector } from "@/app/hooks.ts";
import { login } from "@/features/auth/authSlice.ts";
// import { userLoggedIn } from "@/features/auth/authSlice.ts";
import { selectAllUsers } from "@/features/users/usersSlice.ts";
import { useNavigate } from "react-router";

interface LoginPageFormFields extends HTMLFormControlsCollection {
  username: HTMLSelectElement;
}
interface LoginPageFormElements extends HTMLFormElement {
  readonly elements: LoginPageFormFields;
}

export const LoginPage = () => {
  const dispatch = useAppDispatch();
  const users = useAppSelector(selectAllUsers);
  const navigate = useNavigate();

  return (
    <section>
      <h2>Welcome to Tweeter!</h2>
      <h3>Please log in:</h3>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          // @ts-expect-error: dynamic value, can't be statically inferred
          const username = e.currentTarget.elements.username.value;
          dispatch(login(username));

          navigate("/social-media/posts"); // go to PostsMainPage
        }}
      >
        <label htmlFor="username">User:</label>
        <select id="username" name="username" required>
          <option value=""></option>
          {users.map((user) => (
            <option key={user.id} value={user.id}>
              {user.name}
            </option>
          ))}
        </select>
        <button>Log In</button>
      </form>
    </section>
  );
};

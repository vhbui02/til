import type { RootState } from "@/app/store.ts";
import { createSlice } from "@reduxjs/toolkit";

import { createAppAsyncThunk } from "@/app/withTypes.ts";
import { client } from "@/libs/api-client.ts";

interface AuthState {
  userId: string | null;
}

export const login = createAppAsyncThunk(
  "auth/login",
  // there can be only one argument be passed into the thunk action creator 'login'
  // and whatever passed in becomes the first argument of the payload creation callback
  async (userId: string) => {
    await client.post("/fakeAPI/login", { userId });
    return userId;
  },
);

export const logout = createAppAsyncThunk("auth/logout", async () => {
  await client.post("/fakeAPI/logout", {});
});

const initialState: AuthState = {
  userId: null,
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  // NOTE: pure client logic are deprecated
  // reducers: {
  //   userLoggedIn: (state, action: PayloadAction<string>) => {
  //     state.userId = action.payload;
  //   },
  //   userLoggedOut: (state) => {
  //     state.userId = null;
  //   },
  // },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(login.fulfilled, (state, action) => {
        state.userId = action.payload;
      })
      .addCase(logout.fulfilled, (state) => {
        state.userId = null;
      });
  },
});

//export const { userLoggedIn, userLoggedOut } = authSlice.actions; // deprecated
export const selectCurrentUserID = (state: RootState) => state.auth.userId;
export const authReducer = authSlice.reducer;

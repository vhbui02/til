import { useAppSelector } from "@/app/hooks.ts";
import { selectPostsByUser } from "@/features/posts/postsSlice.ts";
import { selectUserById } from "@/features/users/usersSlice.ts";
import { Link, useParams } from "react-router";

export const UserPage = () => {
  const { userId } = useParams();

  const user = useAppSelector((state) => selectUserById(state, userId!));
  const postsForUser = useAppSelector((state) =>
    selectPostsByUser(state, userId!),
  ); // always run when dispatching action (it's inevitable), but if the reference is stable, component will NOT re-render

  if (!user) {
    return (
      <section>
        <h2>User not found!</h2>
      </section>
    );
  }

  return (
    <section>
      <h2>{user.name}</h2>

      <ul>
        {postsForUser.map((post) => (
          <li key={post.id}>
            <Link to={`/posts/${post.id}`}>{post.title}</Link>
          </li>
        ))}
      </ul>
    </section>
  );
};

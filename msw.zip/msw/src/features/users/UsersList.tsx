import { useAppSelector } from "@/app/hooks.ts";
import { selectAllUsers } from "@/features/users/usersSlice.ts";
import { Link } from "react-router";

export const UsersList = () => {
  const users = useAppSelector(selectAllUsers);
  return (
    <section>
      <h2>Users</h2>
      <ul>
        {users.map((user) => (
          <li key={user.id}>
            <Link to={`/users/${user.id}`}>{user.name}</Link>
          </li>
        ))}
      </ul>
    </section>
  );
};

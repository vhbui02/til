import type { RootState } from "@/app/store.ts";
import { createAppAsyncThunk } from "@/app/withTypes.ts";
import { selectCurrentUserID } from "@/features/auth/authSlice.ts";
import { createEntityAdapter, createSlice } from "@reduxjs/toolkit";

interface User {
  id: string;
  name: string;
}

// const initialState: User[] = [
//   { id: "0", name: "Tianna Jenkins" },
//   { id: "1", name: "Kevin Grant" },
//   { id: "2", name: "Madison Price" },
// ];

const usersAdapter = createEntityAdapter<User>();

const initialState = usersAdapter.getInitialState();

export const fetchUsers = createAppAsyncThunk(
  "users/fetchUsers",
  async (_, { extra }) => {
    const response = await extra.api.get<User[]>("/fakeApi/users");
    return response.data;
  },
);

const usersSlice = createSlice({
  name: "users",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(fetchUsers.fulfilled, usersAdapter.setAll);
  },
});

export const usersReducer = usersSlice.reducer;

// TIPS: selectAllSomething is naming convention from Redux createEntityAdapter() API
// export const selectAllUsers = (state: RootState) => state.users;
// export const selectUserById = (state: RootState, userId: string | null) =>
//   state.users.find((user) => user.id === userId);

export const { selectAll: selectAllUsers, selectById: selectUserById } =
  usersAdapter.getSelectors((state: RootState) => state.users);

export const selectCurrentUser = (state: RootState) => {
  const currentUsername = selectCurrentUserID(state); // selector defined within createSlice.selectors
  if (!currentUsername) {
    return null;
  }
  return selectUserById(state, currentUsername);
};

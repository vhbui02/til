import { useAppDispatch, useAppSelector } from "@/app/hooks.ts";
import { TimeAgo } from "@/components/TimeAgo.tsx";
import {
  allNotificationsRead,
  selectAllNotifications,
} from "@/features/notifications/notificationSlice.ts";
import { PostAuthor } from "@/features/posts/PostAuthor.tsx";
import { useLayoutEffect } from "react";

export const NotificationsList = () => {
  const dispatch = useAppDispatch();
  const notifications = useAppSelector(selectAllNotifications); // use state.notifications => unnecessary re-renders

  // TODO: add condition to dispatch: dispatch once when mounted, and only re-dispatch when the size of the notification changes.
  // run twice
  // 1st run: when NotificationsList is mounted
  // 2nd run: when 'notifications' return from useAppSelector() changes due to dispatch(allNotificationsRead()), however, 2nd run doesn't change anything => stop here
  useLayoutEffect(() => {
    dispatch(allNotificationsRead()); // modify state.notifications
  });

  return (
    <section className="notificationsList">
      <h2>Notifications</h2>
      {notifications.map((notification) => {
        const notificationClassname = notification.isNew
          ? "notification new"
          : "notification";
        return (
          <div key={notification.id} className={notificationClassname}>
            <div>
              <b>
                <PostAuthor userId={notification.user} showPrefix={false} />
              </b>{" "}
              {notification.message}
            </div>
            <TimeAgo timestamp={notification.date} />
          </div>
        );
      })}
    </section>
  );
};

import { createSlice } from "@reduxjs/toolkit";

import type { RootState } from "@/app/store";
import { createAppAsyncThunk } from "@/app/withTypes";
import { createEntityAdapter } from "@reduxjs/toolkit";

export interface ServerNotification {
  id: string;
  date: string;
  message: string;
  user: string;
}

export interface ClientNotification extends ServerNotification {
  read: boolean;
  isNew: boolean;
}

export const fetchNotifications = createAppAsyncThunk(
  "notifications/fetchNotifications",
  async (_, { rejectWithValue, getState, dispatch, signal, extra }) => {
    const allNotifications = selectAllNotifications(getState());

    // second argument a.k.a thunkAPI contains:
    // - `getState()` and `dispatch()` function to dispatch more actions, or get the latest Redux store state
    // 1. multiple sequential steps: fetch data, dispatch an action, send a second API call
    // 2. bailout/cancellation pattern.
    // 3. pagination and cursors

    const [latestNotification] = allNotifications; // NOTE: very interesting syntax
    const latestTimestamp = latestNotification ? latestNotification.date : "";

    // use the creation timestamp of the most recent notification as part of the request so the server knows it should only send back notification that are actually new.
    try {
      const response = await extra.api.get<ServerNotification[]>(
        `/fakeApi/notifications?since=${latestTimestamp}`,
        {
          signal, // cancel network request when user navigate away from the component
        },
      );

      // usage in a component:
      //const promise = dispatch(fetchNotifications());
      //promise.abort(); // might be registered inside useEffect cleanup callback

      return response.data;
    } catch (error: any) {
      // if the BE return a specific error message, extract and return it
      // the reducer function defined in createSlice.extraReducers will receive this custom error message instead as action.payload
      if (error.response && error.response.data.message) {
        return rejectWithValue(error.response.data.message);
      }
      return rejectWithValue("An unknown error occured!");
    }
  },
);

const notificationsAdapter = createEntityAdapter<ClientNotification>({
  sortComparer: (a, b) => b.date.localeCompare(a.date),
});

const initialState = notificationsAdapter.getInitialState();

const notificationsSlice = createSlice({
  name: "notifications",
  initialState,
  reducers: {
    allNotificationsRead: (state) => {
      // state.forEach((notification) => {
      //   notification.read = true;
      // });
      Object.values(state.entities).forEach((notification) => {
        notification.read = true;
      });
    },
  },
  extraReducers: (builder) => {
    builder.addCase(fetchNotifications.fulfilled, (state, action) => {
      const notificationWithMetadata: ClientNotification[] = action.payload.map(
        (notification) => ({
          ...notification,
          isNew: true,
          read: false,
        }),
      );

      // state.forEach((notification) => {
      //   // current notifications that've been read are no longer new, haven't read => still new (new as the previous batch and new as the current fetched batch)
      //   notification.isNew = !notification.read;
      // });

      // state.push(...notificationWithMetadata);
      // // Sort with newest first
      // state.sort((a, b) => b.date.localeCompare(a.date)); // this mutates the 'state' array

      Object.values(state.entities).forEach(
        // NOTE: looping is inevitable
        (notification) => (notification.isNew = !notification.read),
      );

      notificationsAdapter.upsertMany(state, notificationWithMetadata);
    });
  },
});

export const notificationsReducer = notificationsSlice.reducer;

export const { allNotificationsRead } = notificationsSlice.actions;

// export const selectAllNotifications = (state: RootState) => state.notifications;
export const { selectAll: selectAllNotifications } =
  notificationsAdapter.getSelectors((state: RootState) => state.notifications);
export const selectUnreadNotificationsCount = (state: RootState) => {
  // return state.notifications.reduce((acc, curr) => (!curr.read ? acc + 1 : acc), 0);
  const allNotifications = selectAllNotifications(state);
  const unreadNotifications = allNotifications.filter(
    (notification) => !notification.read,
  ); // NOTE: re-filtering everything the selector runs is a bit wasteful, but if  the notifications are new every time according to business logic, it really doesn't matter
  return unreadNotifications.length;
};

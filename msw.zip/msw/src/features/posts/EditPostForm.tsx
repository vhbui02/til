import { useAppDispatch, useAppSelector } from "@/app/hooks.ts";
import { postUpdated, selectPostById } from "@/features/posts/postsSlice";
import { useNavigate, useParams } from "react-router";

export const EditPostForm = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const { postId } = useParams();
  const post = useAppSelector((state) => selectPostById(state, postId!)); // this is a safe assumption since we know the routing setup only shows <EditPostForm> if there's a post ID in the URL

  if (!post) {
    return (
      <section>
        <h2>Post not found!</h2>
      </section>
    );
  }

  return (
    <section>
      <h2>Edit Post</h2>
      <form
        onSubmit={(e) => {
          e.preventDefault(); // prevent server submission
          const { elements } = e.currentTarget;
          // @ts-expect-error: dynamic value, can't be statically inferred
          const title = elements.postTitle;
          // @ts-expect-error: dynamic value, can't be statically inferred
          const content = elements.postContent;
          if (title && content) {
            dispatch(postUpdated({ id: post.id, title, content }));
            navigate(`/social-media/posts/${post.id}`); // go back to SinglePostPage
          }
        }}
      >
        <label htmlFor="postTitle">Post Title:</label>
        <input
          type="text"
          id="postTitle"
          name="postTitle"
          defaultValue={post.title}
          required
        />
        <label htmlFor="postContent">Content:</label>
        <textarea
          id="postContent"
          name="postContent"
          defaultValue={post.content}
          required
        />

        <button>Save Post</button>
      </form>
    </section>
  );
};

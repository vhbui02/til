import type { AppStartListening } from "@/app/listenerMiddleware.ts";
import type { RootState } from "@/app/store.ts";
import { createAppAsyncThunk } from "@/app/withTypes.ts";
import { logout } from "@/features/auth/authSlice.ts";

// import { userLoggedOut } from "@/features/auth/authSlice.ts";
import {
  createEntityAdapter,
  createSelector,
  createSlice,
  nanoid,
  type EntityState,
  type PayloadAction,
} from "@reduxjs/toolkit";

export interface Reactions {
  thumbsUp: number;
  tada: number;
  heart: number;
  rocket: number;
  eyes: number;
}

export type ReactionName = keyof Reactions;

export interface Post {
  id: string;
  title: string;
  content: string;
  userId: string;
  date: string;
  reactions: Reactions;
}

type PostUpdate = Pick<Post, "id" | "title" | "content">;
type NewPost = Pick<Post, "title" | "content" | "userId">;

// const initialReactions: Reactions = {
//   thumbsUp: 0,
//   tada: 0,
//   heart: 0,
//   rocket: 0,
//   eyes: 0,
// };

// const initialState: Post[] = [
//   {
//     id: "1",
//     title: "First Post!",
//     content: "Hello!",
//     userId: "0",
//     date: sub(new Date(), { minutes: 10 }).toISOString(),
//     reactions: initialReactions,
//   },
//   {
//     id: "2",
//     title: "Second Post",
//     content: "More text",
//     userId: "2",
//     date: sub(new Date(), { minutes: 5 }).toISOString(),
//     reactions: initialReactions,
//   },
// ];

// data fetching
export const fetchPosts = createAppAsyncThunk(
  "posts/fetchPosts",
  async (_, { extra }) => {
    const response = await extra.api.get<Post[]>("/fakeApi/posts");
    return response.data;
  },
  {
    condition(arg, thunkApi) {
      const postsStatus = selectPostsStatus(thunkApi.getState());
      if (postsStatus !== "idle") {
        return false;
      }
    },
  },
);

export const addNewPost = createAppAsyncThunk(
  "posts/addNewPost",
  async (initialPost: NewPost, { extra }) => {
    const response = await extra.api.post<Post>("/fakeApi/posts", initialPost);
    return response.data; // make sure the data type is Post
  },
);

// normalization
interface PostsState extends EntityState<Post, string> {
  status: "idle" | "pending" | "succeeded" | "rejected";
  error: string | null;
}

const postsAdapter = createEntityAdapter<Post>({
  sortComparer: (a, b) => b.date.localeCompare(a.date),
});

const initialState: PostsState = postsAdapter.getInitialState({
  status: "idle",
  error: null,
});

const postsSlice = createSlice({
  name: "posts",
  initialState,
  reducers: {
    // Declare a "case reducer" named `postAdded`.
    // The type of `action.payload` will be a `Post` object.

    // postAdded: (
    //   state,
    //   action: PayloadAction<Post> /* add type to action.payload, type inference for postAdded */,
    // ) => {
    //   // "Mutate" the existing state array, which is
    //   // safe to do here because `createSlice` uses Immer inside.
    //   state.push(action.payload);
    // },

    // postAdded: {
    //   reducer: (state, action: PayloadAction<Post>) => {
    //     state.push(action.payload);
    //   },
    //   // NOTE: relieve the duty of knowing what the payload object should look like from the component
    //   prepare: (title: string, content: string, userId: string) => {
    //     return {
    //       payload: {
    //         id: nanoid(),
    //         title,
    //         content,
    //         userId,
    //         date: new Date().toISOString(),
    //         reactions: initialReactions,
    //       },
    //       //meta:
    //       //error:
    //     };
    //   },
    // },

    // NOTE: Naming convention - past-tense "thisHappened"
    postUpdated: (state, action: PayloadAction<PostUpdate>) => {
      const { id, title, content } = action.payload;
      // const existingPost = state.find((post) => post.id === id);
      // if (existingPost) {
      //   existingPost.title = title;
      //   existingPost.content = content;
      // }
      postsAdapter.updateOne(state, {
        id,
        changes: {
          title,
          content,
        },
      });
    },

    reactionAdded: (
      state,
      // NOTE: action object always contain the minimum amount of information needed, do the state update in the reducer
      // reducers can contain as much logic as necessary to calculate the new state
      // state update logic should in a reducer
      action: PayloadAction<{ postId: string; reactionName: ReactionName }>,
    ) => {
      const { postId, reactionName } = action.payload;
      // const existingPost = state.find((post) => post.id === postId);
      const existingPost = state.entities[postId];
      if (existingPost) {
        existingPost.reactions[reactionName]++;
      }
    },
  },
  // selectors: {
  //   // unlike writing a standalone selector function, the `state` argument to these selectors will be just the slice state, not the RootState
  //   selectPosts: (postsState) => postsState,
  //   selectPostById: (postsState, postId: string) =>
  //     postsState.find((post) => post.id === postId),
  // },
  // many different reducers can all respond to the same dispatched action, and each slice can update its own state if needed
  extraReducers: (builder) => {
    // listen to an action creator
    builder
      .addCase(logout.fulfilled, (state) => {
        return initialState; // NOTE: instead of returning an empty array, return initial state is a better idea
      })
      .addCase(fetchPosts.pending, (state, action) => {
        state.status = "pending";
      })
      .addCase(fetchPosts.fulfilled, (state, action) => {
        state.status = "succeeded";
        postsAdapter.setAll(state, action.payload); // pre-built CRUD reducer function
      })
      .addCase(fetchPosts.rejected, (state, action) => {
        state.status = "rejected";
        state.error = action.error.message ?? "Unknown Error";
      })
      .addCase(addNewPost.fulfilled, postsAdapter.addOne);
  },
});

// postAdded is an example of a "case reducer" - a reducer function within a slice that handles one specific action type that was dispatched
// analog:
// function sliceReducer(state = initialState, action) {
//   switch (action.type) {
//     case "posts/postAdded": {
//       // update logic here
//     }
//   }
// }

// Export the auto-generated action creator with the same name
export const { /* postAdded, */ postUpdated, reactionAdded } =
  postsSlice.actions;
// export const { selectPosts, selectPostById } = postsSlice.selectors;

export const postsReducer = postsSlice.reducer;

// pre-built selector
export const {
  selectAll: selectAllPosts,
  selectById: selectPostById,
  selectIds: selectPostIds,
} = postsAdapter.getSelectors((state: RootState) => state.posts);

// TIPS: you do not have to write selector for every single field of your state!
// export const selectAllPosts = (state: RootState) => state.posts;

// 1st attempt: "curried selector factory", cannot memoize
// export const selectPostById = (id: string) => (state: RootState) => state.posts.find((post) => post.id === id);

// 2nd attempt
// export const selectPostById = createSelector(
//   [(state: RootState) => state.posts, (state: RootState, id: string) => id],
//   (posts, id) => posts.find((post) => post.id === id),
// );

// 1nd attempt: return new array reference regardless of whether state or userId changed or not
// Tips: After checking Redux Profiler: UserPage re-renders and doesn't use notifications state yet all state changes coming from notification actions and thunks
// Tips: Also check warning in browser devtool's console page
export const selectPostsByUserLegacy = (state: RootState, userId: string) => {
  const allPosts = selectAllPosts(state);
  return allPosts.filter((post) => post.userId === userId); // CAUTION: this always create an array reference
};

// split the 'gathering' from the 'calculating'
// 1. it runs the input selectors first
// 2. then it looks at the result of the input selectors and check if any of them changed
// 3. if no: completely skipped the output functions and immediately returns the cached result from the last time it run.
// 4. if no: execute the output functions using the result of the input selectors
export const selectPostsByUser = createSelector(
  // e.g., if useAppSelector(selectPostsByUser(state, userId!)) is called, both 'state' and 'userId' is passed into all combiner callbacks specified at the first argument
  [selectAllPosts, (state: RootState, userId: string) => userId],
  (posts, userId) => posts.filter((post) => post.userId === userId),
);

// CAUTION: only use createSelector() if the return value is an object or array reference, or if the calculation is expensive
export const selectPostIDsByUser = createSelector(
  [selectPostsByUser] /* input: state, userId; output: posts */,
  (userPosts) => userPosts.map((post) => post.id),
);

export const selectPostsStatus = (state: RootState) => state.posts.status;
export const selectPostsError = (state: RootState) => state.posts.error;

// use this instead of extraReducers when you want to introduce side-effect typically from an async operations
// you can't do that inside an extraReducers
export const addPostListeners = (startAppListening: AppStartListening) => {
  // called the startAppListening that was injected into addPostListeners
  startAppListening({
    actionCreator: addNewPost.fulfilled, // registered which action creator when dispatched will trigger this logic
    /* matcher: run the effect any time the matcher returns true */
    /* predicate: a more general matching function */
    effect: async (
      action,
      // @ts-ignore
      {
        dispatch,
        getState,
        delay,
        subscribe,
        unsubscribe, // unsubscribe/subscribe: change whether the listener entry is active
        signal,
        extra,
        condition, // pause until some other action is dispatched or state value changed
      },
    ) => {
      // import react-tiny-toast
      // run toast.show(), extract toast ID
      // wait
      // remove toast using toast ID
    },
  });
};

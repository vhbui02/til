import { useAppDispatch, useAppSelector } from "@/app/hooks.ts";
import { selectCurrentUserID } from "@/features/auth/authSlice.ts";
import { addNewPost } from "@/features/posts/postsSlice.ts";
import { selectAllUsers } from "@/features/users/usersSlice.ts";

// TS types for the input fields
// See: https://epicreact.dev/how-to-type-a-react-form-on-submit-handler/
interface AddPostFormFields extends HTMLFormControlsCollection {
  postTitle: HTMLInputElement;
  postContent: HTMLTextAreaElement;
}
interface AddPostFormElements extends HTMLFormElement {
  readonly elements: AddPostFormFields;
}

export const AddPostForm = () => {
  const dispatch = useAppDispatch();
  const users = useAppSelector(selectAllUsers);
  const userId = useAppSelector(selectCurrentUserID)!;

  return (
    <section>
      <h2>Add a New Post</h2>
      <form
        onSubmit={(e) => {
          // Prevent server submission
          e.preventDefault();

          const { elements } = e.currentTarget;
          // @ts-expect-error: dynamic value, can't be statically inferred
          const title = elements.postTitle.value;
          // @ts-expect-error: dynamic value, can't be statically inferred
          const content = elements.postContent.value;
          // const userId = elements.postAuthor.value;
          dispatch(
            addNewPost({
              title,
              content,
              userId,
            }),
          );

          e.currentTarget.reset();
        }}
      >
        <label htmlFor="postTitle">Post Title:</label>
        {/* uncontrolled input */}
        <input
          type="text"
          id="postTitle"
          name="postTitle"
          defaultValue=""
          required
        />

        {/* <label htmlFor="postAuthor">Author:</label>
        <select id="postAuthor" name="postAuthor" required>
          <option value=""></option>
          {users.map((user) => (
            <option key={user.id} value={user.id}>
              {user.name}
            </option>
          ))}
        </select> */}

        <label htmlFor="postContent">Content:</label>
        <textarea
          id="postContent"
          name="postContent"
          defaultValue=""
          required
        />
        <button>Save Post</button>
      </form>
    </section>
  );
};

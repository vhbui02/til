import { Outlet } from "react-router";

export const SocialMediaLayout = () => {
  return <Outlet />;
};

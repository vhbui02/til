import { useAppSelector } from "@/app/hooks.ts";
import { TimeAgo } from "@/components/TimeAgo.tsx";
import { PostAuthor } from "@/features/posts/PostAuthor.tsx";
import { selectPostById, selectPostIds } from "@/features/posts/postsSlice";
import { ReactionButtons } from "@/features/posts/ReactionButtons.tsx";
import { Link } from "react-router";

const PostExcerpt = ({ postId }: { postId: string }) => {
  const post = useAppSelector((state) => selectPostById(state, postId));

  if (!post) {
    return null;
  }

  return (
    <article className="post-excerpt" key={post.id}>
      <h3>
        <Link to={`/social-media/posts/${post.id}`}>{post.title}</Link>
      </h3>
      <div>
        <PostAuthor userId={post.userId} />
        <TimeAgo timestamp={post.date} />
      </div>
      <p className="post-content">{post.content.substring(0, 100)}</p>
      <ReactionButtons post={post} />
    </article>
  );
};

export const PostsList = () => {
  // there are two design approaches:
  // 1. extract the full post array, then passed each post into a React.memo(PostExcerpt) wrapped component
  // 2. extract only the post ID array, then passed each post ID directly into PostExcerpt component
  //const posts = useAppSelector(selectAllPosts);
  //const orderedPosts = useMemo(
  //  () => posts.slice().sort((a, b) => b.date.localeCompare(a.date)),
  //  [],
  //);
  const orderedPostIds = useAppSelector(selectPostIds);

  return (
    <section className="posts-list">
      <h2>Posts</h2>
      {orderedPostIds.map((postId) => (
        <PostExcerpt postId={postId} />
      ))}
    </section>
  );
};

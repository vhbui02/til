import { useAppDispatch } from "@/app/hooks";

import type { Post, ReactionName } from "./postsSlice";
import { reactionAdded } from "./postsSlice";

const reactionEmoji: Record<ReactionName, string> = {
  thumbsUp: "?",
  tada: "?",
  heart: "??",
  rocket: "?",
  eyes: "?",
};

interface ReactionButtonsProps {
  post: Post;
}

export const ReactionButtons = ({ post }: ReactionButtonsProps) => {
  const dispatch = useAppDispatch();

  const reactionButtons = Object.entries(reactionEmoji).map(
    ([stringName, emoji]) => {
      // Ensure TS knows this is a _specific_ string type
      const reactionName = stringName as ReactionName;
      return (
        <button
          key={reactionName}
          type="button"
          className="muted-button reaction-button"
          onClick={() =>
            dispatch(reactionAdded({ postId: post.id, reactionName }))
          }
        >
          {emoji} {post.reactions[reactionName]}
        </button>
      );
    },
  );

  return <div>{reactionButtons}</div>;
};

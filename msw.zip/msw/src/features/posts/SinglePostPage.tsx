import { useAppSelector } from "@/app/hooks.ts";
import { TimeAgo } from "@/components/TimeAgo.tsx";
import { selectCurrentUserID } from "@/features/auth/authSlice.ts";
import { PostAuthor } from "@/features/posts/PostAuthor.tsx";
import { selectPostById } from "@/features/posts/postsSlice";
import { ReactionButtons } from "@/features/posts/ReactionButtons.tsx";
import { Link, useParams } from "react-router";

type SinglePostPageParams = {
  postId: string;
};

export const SinglePostPage = () => {
  const { postId } = useParams<SinglePostPageParams>();
  const post = useAppSelector((state) => selectPostById(state, postId!));
  const currentUsername = useAppSelector(selectCurrentUserID)!;

  if (!post) {
    return (
      <section>
        <h2>Post not found!</h2>
      </section>
    );
  }

  const canEdit = currentUsername === post.userId;

  return (
    // dedicated page
    <section>
      <article className="post">
        <h2>{post.title}</h2>
        <PostAuthor userId={post.userId} />
        <TimeAgo timestamp={post.date} />
        <p className="post-content">{post.content}</p>
        <ReactionButtons post={post} />
        {canEdit && (
          <Link to={`/social-media/posts/${post.id}/actions/edit`}>
            Edit Post
          </Link>
        )}
      </article>
    </section>
  );
};

import { useState } from "react";

// use pre-typed versions of the react-redux
import { useAppDispatch, useAppSelector } from "@/app/hooks";
import {
  decrement,
  increment,
  incrementAsync,
  incrementByAmount,
  selectCount,
  selectStatus,
} from "@/features/counter/counterSlice.ts";

import styles from "./counter.module.css";

export const Counter = () => {
  const dispatch = useAppDispatch(); // since we don't have access to the store, we use this hook to access the dispatch instead
  const count = useAppSelector(selectCount);
  const status = useAppSelector(selectStatus);

  // the only place that needs the increment amount is Counter component => it's component state, not global state
  const [incrementAmount, setIncrementAmount] = useState("2");
  const incrementValue = Number(incrementAmount) || 0;

  return (
    <div>
      <div className={styles.row}>
        <button
          className={styles.button}
          aria-label="Decrement value"
          onClick={() => {
            dispatch(decrement());
          }}
        >
          -
        </button>

        <span aria-label="count" className={styles.value}>
          {count}
        </span>

        <button
          className={styles.button}
          aria-label="Increment value"
          onClick={() => {
            dispatch(increment());
          }}
        >
          +
        </button>
      </div>

      <div>
        <input
          className={styles.textbox}
          aria-label="Set increment amount"
          onChange={(e) => setIncrementAmount(e.target.value)}
          value={incrementAmount}
        />
        <button
          className={styles.button}
          onClick={() => dispatch(incrementByAmount(incrementValue))}
        >
          Add Amount
        </button>
        <button
          className={styles.button}
          onClick={() => dispatch(incrementAsync(incrementValue))}
        >
          Add Async
        </button>
      </div>
    </div>
  );
};
